# J.A.R.V.I.S — Android

Windows sürümünün (Tkinter + Gemini Live) Android'e uyarlanmış hali.
Kotlin + Jetpack Compose ile yazıldı, Gemini REST API + function calling,
Android SpeechRecognizer (STT) ve TextToSpeech (TTS) kullanır.

## Neler taşındı, neler farklı çalışıyor

✅ Birebir: Gemini ile sohbet, sesli komut, sesli yanıt, uygulama açma,
hava durumu, takvim okuma/ekleme, YouTube/tarayıcı açma, kalıcı hafıza (save/delete memory)

⚠️ Farklı çalışıyor (Android'in güvenlik modeli gereği):
- **shell_run** (terminal komutları) → Android'de genel terminal erişimi yok, kaldırıldı
- **WhatsApp otomasyonu** → Android'de doğrudan mesaj gönderme yerine WhatsApp'ı
  açıp konuşmaya yönlendirme eklenebilir (şu an dahil değil, istersen ekleriz)
- **Ekran analizi (screen_vision)** → Android'de `MediaProjection` API ile
  yapılabilir ama her seferinde kullanıcı onayı ister (şu an dahil değil)
- **Takvim/Hatırlatıcılar** → Apple Calendar yerine Android'in kendi
  `CalendarContract` API'si (telefonda senkronize olan Google Takvim'i kullanır)

---

## Kurulum ve Build (APK almak için)

### 1. Android Studio kur
https://developer.android.com/studio adresinden indir, kur, aç.

### 2. Projeyi aç
- Android Studio'da **File → Open**
- Sana vereceğim `JarvisAndroid` klasörünü seç
- Açılınca sağ altta "Gradle Sync" başlar, internet ister (kütüphaneleri indirir).
  İlk seferinde birkaç dakika sürebilir. Bitene kadar bekle.
- Eğer "Gradle wrapper eksik" gibi bir uyarı çıkarsa Android Studio otomatik
  olarak "Sync now" veya "Fix" butonu gösterir, ona tıkla.

### 3. Gemini API anahtarı
Zaten uygulama ilk açıldığında API anahtarı ekranı çıkacak — kod içine
anahtar yazmana gerek yok. Ama istersen test için:
https://aistudio.google.com → Get API Key → Create API Key

### 4. Telefonda çalıştır (test için, en kolay yol)
- Telefonunda **Ayarlar → Telefon Hakkında → Yapı Numarası**'na 7 kez dokun
  (Geliştirici Seçenekleri açılır)
- **Ayarlar → Geliştirici Seçenekleri → USB Hata Ayıklama**'yı aç
- Telefonu USB ile bilgisayara bağla, telefonda çıkan izin isteğini onayla
- Android Studio'da üstte cihazının adı görünecek, yanındaki yeşil ▶ (Run)
  butonuna bas
- Uygulama telefonuna otomatik kurulup açılır

### 5. Paylaşılabilir APK oluşturmak (Build)
Telefona kablosuz kurmak veya başkasına göndermek istiyorsan:

- Android Studio'da üst menüden:
  **Build → Build Bundle(s) / APK(s) → Build APK(s)**
- Build bitince sağ altta "locate" linkine tıkla, ya da şu klasöre bak:
  ```
  JarvisAndroid/app/build/outputs/apk/debug/app-debug.apk
  ```
- Bu `app-debug.apk` dosyasını telefonuna kopyalayıp (WhatsApp, Google Drive,
  USB kablo ile) dokunarak kurabilirsin. "Bilinmeyen kaynaklardan yükleme"
  izni istenirse onayla.

**Not:** Bu "debug" APK'dır — kendi telefonunda kullanmak için tamamen yeterli.
Google Play'e yüklemek veya "resmi" bir sürüm yayınlamak istersen ayrıca
**imzalı release APK** oluşturmak gerekir (Build → Generate Signed Bundle/APK),
o zaman ayrı anlatırım.

---

## Bilinen sınırlamalar
- Gemini Live'daki gerçek zamanlı ses akışı yerine STT→metin→Gemini→TTS
  akışı kullanılıyor; yani JARVIS konuşurken araya girip kesemezsin
  (Windows sürümünde de pratikte fark az hissedilir).
- "Çift alkış ile uyanma" (wake gesture) şu anki sürümde yok; mikrofon
  butonuna basarak başlatılıyor. İstersen arka planda dinleyen bir
  servis olarak da ekleyebiliriz (pil tüketimini artırır).
