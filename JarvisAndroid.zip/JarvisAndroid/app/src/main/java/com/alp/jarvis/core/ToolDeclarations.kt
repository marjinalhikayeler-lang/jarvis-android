package com.alp.jarvis.core

import org.json.JSONArray
import org.json.JSONObject

/**
 * Gemini function-calling icin arac (tool) semalari.
 * Windows suerumundeki TOOL_DECLARATIONS listesinin Android'e uyarlanmis hali.
 */
object ToolDeclarations {

    private fun param(type: String, description: String, enumValues: List<String>? = null): JSONObject {
        val o = JSONObject()
        o.put("type", type)
        o.put("description", description)
        if (enumValues != null) o.put("enum", JSONArray(enumValues))
        return o
    }

    private fun tool(name: String, description: String, properties: JSONObject, required: List<String>): JSONObject {
        val params = JSONObject()
        params.put("type", "OBJECT")
        params.put("properties", properties)
        params.put("required", JSONArray(required))

        val t = JSONObject()
        t.put("name", name)
        t.put("description", description)
        t.put("parameters", params)
        return t
    }

    fun all(): JSONArray {
        val list = JSONArray()

        list.put(
            tool(
                "open_app",
                "Telefonda yuklu bir uygulamayi acar. Spotify, Chrome, YouTube, WhatsApp vb.",
                JSONObject().put("app_name", param("STRING", "Acilacak uygulamanin adi")),
                listOf("app_name")
            )
        )

        list.put(
            tool(
                "sys_info",
                "Sistem bilgisi dondurur (pil, saat, tarih).",
                JSONObject().put(
                    "kind",
                    param("STRING", "Istenen bilgi turu", listOf("battery", "time", "date"))
                ),
                listOf("kind")
            )
        )

        list.put(
            tool(
                "get_weather",
                "Belirtilen konum icin hava durumu ozetini verir.",
                JSONObject().put("location", param("STRING", "Sehir/konum adi")),
                listOf("location")
            )
        )

        list.put(
            tool(
                "get_calendar_events",
                "Google Takvim'deki etkinlikleri sorgular.",
                JSONObject().put("query", param("STRING", "today, tomorrow, next, veya dogal dil sorgusu")),
                listOf("query")
            )
        )

        list.put(
            tool(
                "add_calendar_event",
                "Google Takvim'e yeni etkinlik ekler.",
                JSONObject()
                    .put("title", param("STRING", "Etkinlik basligi"))
                    .put("start_iso", param("STRING", "Baslangic zamani ISO 8601 formatinda"))
                    .put("end_iso", param("STRING", "Bitis zamani ISO 8601 formatinda (opsiyonel)")),
                listOf("title", "start_iso")
            )
        )

        list.put(
            tool(
                "open_browser",
                "Tarayicida arama yapar veya dogrudan URL acar.",
                JSONObject()
                    .put("mode", param("STRING", "search veya url", listOf("search", "url")))
                    .put("query", param("STRING", "Arama sorgusu veya URL")),
                listOf("mode", "query")
            )
        )

        list.put(
            tool(
                "open_youtube",
                "YouTube'da video/muzik arar ve acar.",
                JSONObject().put("query", param("STRING", "Aranacak video/sarki adi")),
                listOf("query")
            )
        )

        list.put(
            tool(
                "save_memory",
                "Kullanici hakkinda onemli bir bilgiyi kalici hafizaya kaydeder.",
                JSONObject()
                    .put("category", param("STRING", "Bilginin kategorisi, orn. kisisel, tercih"))
                    .put("key", param("STRING", "Kisa anahtar"))
                    .put("value", param("STRING", "Saklanacak deger")),
                listOf("category", "key", "value")
            )
        )

        list.put(
            tool(
                "delete_memory",
                "Kalici hafizadaki bir kaydi siler.",
                JSONObject().put("match_text", param("STRING", "Silinecek kaydi tanimlayan metin")),
                listOf("match_text")
            )
        )

        list.put(
            tool(
                "open_camera",
                "Telefonun kamerasini acar; JARVIS bu andan itibaren kamera goruntusunu gorebilir (kullanici bir nesne gosterip 'bu ne' diye sorabilir).",
                JSONObject(),
                emptyList()
            )
        )

        list.put(
            tool(
                "close_camera",
                "Acik olan kamerayi kapatir.",
                JSONObject(),
                emptyList()
            )
        )

        list.put(
            tool(
                "set_volume",
                "Medya ses seviyesini belirtilen yuzdeye ayarlar (0-100).",
                JSONObject().put("percent", param("NUMBER", "Hedef ses seviyesi, 0-100 arasi")),
                listOf("percent")
            )
        )

        list.put(
            tool(
                "adjust_volume",
                "Ses seviyesini mevcut degerin uzerine/altina yuzde puan olarak degistirir. Kismak icin negatif deger kullan.",
                JSONObject().put("delta_percent", param("NUMBER", "Ornegin -10 (kismak) veya +10 (artirmak)")),
                listOf("delta_percent")
            )
        )

        list.put(
            tool(
                "send_whatsapp_message",
                "Rehberdeki bir kisiye WhatsApp'tan mesaj yazar ve gonderir (erisilebilirlik izni aciksa otomatik gonderilir, kapaliysa kullanici son dokunusu yapar).",
                JSONObject()
                    .put("contact_name", param("STRING", "Rehberdeki kisinin adi, orn. 'annem'"))
                    .put("message", param("STRING", "Gonderilecek mesaj metni")),
                listOf("contact_name", "message")
            )
        )

        list.put(
            tool(
                "call_contact",
                "Rehberdeki bir kisiyi arar.",
                JSONObject()
                    .put("contact_name", param("STRING", "Rehberdeki kisinin adi"))
                    .put("via", param("STRING", "Arama yontemi: 'whatsapp' veya 'phone' (normal hat). Kullanici 'whatsapp'tan ara' derse whatsapp, aksi halde phone", listOf("whatsapp", "phone"))),
                listOf("contact_name", "via")
            )
        )

        list.put(
            tool(
                "open_spotify",
                "Spotify'da bir sarki arar ve calar (erisilebilirlik izni aciksa ilk sonuca otomatik dokunulur, kapaliysa kullanici secer).",
                JSONObject().put("query", param("STRING", "Aranacak sarki/sanatci adi")),
                listOf("query")
            )
        )

        list.put(
            tool(
                "answer_call",
                "O an calmakta olan telefon aramasini acar.",
                JSONObject(),
                emptyList()
            )
        )

        list.put(
            tool(
                "set_call_auto_reject",
                "Gelen aramalarin otomatik reddedilip reddedilmeyecegini ayarlar (surekli mod, tek seferlik degil).",
                JSONObject().put("enabled", param("BOOLEAN", "true: tum gelen aramalari reddet, false: normal calsin")),
                listOf("enabled")
            )
        )

        list.put(
            tool(
                "ui_tap",
                "O an ekranda acik olan HERHANGI BIR uygulamada, verilen metni iceren bir dugmeye/ogeye dokunur. Genelde once open_app ile uygulama acilir, sonra bu cagrilir. Herhangi bir uygulama icin genel amacli otomasyon.",
                JSONObject().put("text", param("STRING", "Dokunulacak ogenin uzerindeki/yanindaki metin, orn. 'Kaydet', 'Beğen', 'Takip Et'")),
                listOf("text")
            )
        )

        list.put(
            tool(
                "ui_type",
                "O an odakta olan (tiklanmis) bir yazi kutusuna metin yazar. Once ui_tap ile kutuya dokunulmus olmasi gerekebilir.",
                JSONObject().put("text", param("STRING", "Yazilacak metin")),
                listOf("text")
            )
        )

        list.put(
            tool(
                "ui_scroll",
                "Ekrani yukari veya asagi kaydirir.",
                JSONObject().put("direction", param("STRING", "'down' veya 'up'", listOf("down", "up"))),
                listOf("direction")
            )
        )

        list.put(
            tool(
                "ui_back",
                "Telefonun geri tusuna basar.",
                JSONObject(),
                emptyList()
            )
        )

        list.put(
            tool(
                "ui_home",
                "Ana ekrana doner.",
                JSONObject(),
                emptyList()
            )
        )

        return list
    }
}
