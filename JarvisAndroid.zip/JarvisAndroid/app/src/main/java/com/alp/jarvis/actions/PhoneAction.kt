package com.alp.jarvis.actions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat

/**
 * WhatsApp'in kendi sesli/goruntulu aramasini disaridan tetikleyen resmi
 * bir Android API'si yok. Bu yuzden "ara" komutu normal telefon hatti
 * uzerinden arama yapar (WhatsApp degil). CALL_PHONE izni verilmemisse
 * arama ekranini acik birakip kullanicinin kendisi aramasini saglar.
 */
object PhoneAction {

    fun call(context: Context, contactName: String): String {
        val number = ContactsAction.findPhoneNumber(context, contactName)
            ?: return "\"$contactName\" adında bir kişi rehberde bulunamadı."

        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED

        val action = if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL
        val intent = Intent(action, Uri.parse("tel:$number")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)

        return if (granted) "$contactName aranıyor."
        else "$contactName için arama ekranını açtım, arama iznini vermediğim için son dokunuşu sen yapmalısın."
    }
}
