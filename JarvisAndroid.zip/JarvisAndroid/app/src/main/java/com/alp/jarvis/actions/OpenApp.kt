package com.alp.jarvis.actions

import android.content.Context
import android.content.pm.PackageManager

/**
 * Windows suerumundeki actions/open_app.py karsiligi.
 * Android'de uygulamalar isim degil paket adiyla acilir; bu yuzden
 * kurulu uygulamalarin gorunen adlarini paket adlarina eslestiriyoruz.
 */
object OpenApp {

    // Sik kullanilan uygulamalar icin bilinen paket adlari (bulunamazsa
    // otomatik arama devreye girer).
    private val KNOWN_PACKAGES = mapOf(
        "spotify" to "com.spotify.music",
        "chrome" to "com.android.chrome",
        "youtube" to "com.google.android.youtube",
        "whatsapp" to "com.whatsapp",
        "instagram" to "com.instagram.android",
        "gmail" to "com.google.android.gm",
        "takvim" to "com.google.android.calendar",
        "calendar" to "com.google.android.calendar",
        "ayarlar" to "com.android.settings",
        "settings" to "com.android.settings",
        "telegram" to "org.telegram.messenger",
        "discord" to "com.discord",
        "kamera" to "com.android.camera",
        "camera" to "com.android.camera",
        "galeri" to "com.google.android.apps.photos",
        "photos" to "com.google.android.apps.photos",
        "maps" to "com.google.android.apps.maps",
        "haritalar" to "com.google.android.apps.maps",
        "netflix" to "com.netflix.mediaclient",
        "twitter" to "com.twitter.android",
        "x" to "com.twitter.android"
    )

    fun open(context: Context, appName: String): String {
        val pm = context.packageManager
        val normalized = appName.trim().lowercase()

        // 1. Bilinen paket eslesmesi
        KNOWN_PACKAGES[normalized]?.let { pkg ->
            val launch = pm.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                launch.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                return "$appName açılıyor."
            }
        }

        // 2. Kurulu uygulamalar arasinda gorunen isme gore ara
        val installed = pm.getInstalledApplications(0)
        for (appInfo in installed) {
            val label = pm.getApplicationLabel(appInfo).toString()
            if (label.lowercase().contains(normalized) || normalized.contains(label.lowercase())) {
                val launch = pm.getLaunchIntentForPackage(appInfo.packageName)
                if (launch != null) {
                    launch.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launch)
                    return "$label açılıyor."
                }
            }
        }

        return "\"$appName\" adında bir uygulama bulamadım. Telefonda kurulu mu?"
    }
}
