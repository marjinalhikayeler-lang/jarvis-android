package com.alp.jarvis.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.alp.jarvis.MainActivity
import com.alp.jarvis.core.JarvisEngineHolder
import com.alp.jarvis.voice.GeminiAudioRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Kullanici "arka planda dinle" secenegini actiginda baslar. Android,
 * mikrofon kullanan arka plan servisleri icin kalici bir bildirim
 * gosterilmesini zorunlu kilar (gizli dinleme yapilamaz) — bu yuzden
 * "JARVIS dinliyor" bildirimi kaldirilamaz, bu Android'in kuralidir.
 *
 * Android'in yerlesik ses tanimasi bazi cihazlarda calismadigi icin
 * (bkz. GeminiAudioRecorder) burada da ayni Gemini tabanli kayit
 * dongusunu kullaniyoruz: kisa bir sure dinler, sessizlik olunca
 * durur, Gemini'ye yaziya cevirtir, "jarvis" ile baslamiyorsa yoksayip
 * hemen tekrar dinlemeye baslar.
 */
class JarvisBackgroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var audioRecorder: GeminiAudioRecorder? = null

    @Volatile
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())
        running = true
        listenLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        audioRecorder?.cancel()
        mainHandler.removeCallbacksAndMessages(null)
        scope.cancel()
    }

    private fun listenLoop() {
        if (!running) return

        val micGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!micGranted) {
            // Izin kaldirilmis olabilir; birazdan tekrar kontrol et
            mainHandler.postDelayed({ listenLoop() }, 3000)
            return
        }

        audioRecorder = GeminiAudioRecorder(
            onFinished = { wav ->
                if (!running) return@GeminiAudioRecorder
                if (wav == null) {
                    listenLoop() // sessizlik/ses yoktu, hemen tekrar dinle
                    return@GeminiAudioRecorder
                }
                scope.launch {
                    val engine = JarvisEngineHolder.get(applicationContext)
                    val text = engine.transcribeAudio(wav)
                    if (!text.isNullOrBlank()) {
                        engine.handleHeardSpeech(text, requireWakeWord = true)
                    }
                    if (running) listenLoop()
                }
            },
            // "Hey Jarvis" onayindan hemen sonraki takip komutu icin kisa bir
            // bekleme yeterli (3-4 sn); normal dongude daha da kisa tutup
            // sik sik yeniden dinlemeye baslamak, "jarvis" sozunu kacirma
            // ihtimalini azaltir.
            noSpeechTimeoutMs = if (JarvisEngineHolder.get(applicationContext).isInWakeGrace()) 4000L else 6000L
        )

        val started = audioRecorder?.start() ?: false
        if (!started) {
            mainHandler.postDelayed({ listenLoop() }, 2000)
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "jarvis_background"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "JARVIS Arka Plan Dinleme", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val openIntent = Intent(this, MainActivity::class.java)
        val pendingFlags = PendingIntent.FLAG_IMMUTABLE
        val pending = PendingIntent.getActivity(this, 0, openIntent, pendingFlags)

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("JARVIS dinliyor")
            .setContentText("\"Jarvis\" diyerek komut verebilirsin")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val NOTIF_ID = 4242

        fun start(context: android.content.Context) {
            val intent = Intent(context, JarvisBackgroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: android.content.Context) {
            context.stopService(Intent(context, JarvisBackgroundService::class.java))
        }
    }
}
