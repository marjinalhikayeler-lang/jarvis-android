package com.alp.jarvis.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.alp.jarvis.MainActivity
import com.alp.jarvis.core.JarvisEngineHolder
import com.alp.jarvis.voice.ContinuousSpeechListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Kullanici "arka planda dinle" secenegini actiginda baslar. Android,
 * mikrofon kullanan arka plan servisleri icin kalici bir bildirim
 * gosterilmesini zorunlu kilar (gizli dinleme yapilamaz) — bu yuzden
 * "JARVIS dinliyor" bildirimi kaldirilamaz, bu Android'in kuralidir.
 */
class JarvisBackgroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var listenerLoop: ContinuousSpeechListener? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())

        val engine = JarvisEngineHolder.get(applicationContext)
        listenerLoop = ContinuousSpeechListener(applicationContext) { heard ->
            scope.launch {
                engine.handleHeardSpeech(heard, requireWakeWord = true)
            }
        }
        listenerLoop?.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        listenerLoop?.stop()
        scope.cancel()
    }

    private fun buildNotification(): Notification {
        val channelId = "jarvis_background"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "JARVIS Arka Plan Dinleme", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val openIntent = Intent(this, MainActivity::class.java)
        val pendingFlags = PendingIntent.FLAG_IMMUTABLE
        val pending = PendingIntent.getActivity(this, 0, openIntent, pendingFlags)

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("JARVIS dinliyor")
            .setContentText("\"Jarvis\" diyerek komut verebilirsin")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val NOTIF_ID = 4242

        fun start(context: android.content.Context) {
            val intent = Intent(context, JarvisBackgroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: android.content.Context) {
            context.stopService(Intent(context, JarvisBackgroundService::class.java))
        }
    }
}
