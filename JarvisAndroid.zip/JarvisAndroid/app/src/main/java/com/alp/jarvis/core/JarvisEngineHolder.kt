package com.alp.jarvis.core

import android.content.Context

/**
 * Aktivite ve arka plan servisinin AYNI JarvisEngine ornegini (dolayisiyla
 * ayni konusma gecmisini) kullanmasini saglar.
 */
object JarvisEngineHolder {
    @Volatile private var instance: JarvisEngine? = null

    fun get(context: Context): JarvisEngine {
        return instance ?: synchronized(this) {
            instance ?: JarvisEngine(context.applicationContext).also { instance = it }
        }
    }
}
