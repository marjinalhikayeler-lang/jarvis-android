package com.alp.jarvis.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * JARVIS Windows'ta google-genai SDK'siyla Gemini Live'a baglaniyordu.
 * Android'de aynisini standart Gemini REST API (generateContent) +
 * function calling ile yapiyoruz: STT metni buraya gelir, model bir
 * arac cagirmak isterse ("functionCall") onu MainViewModel isler ve
 * sonucu tekrar modele geri gonderir.
 */
class GeminiClient(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val model = "gemini-2.0-flash"
    private val baseUrl = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"

    data class GeminiResult(
        val text: String?,
        val functionCall: Pair<String, JSONObject>? // name, args
    )

    /**
     * history: onceki mesajlar [{role: "user"/"model", parts: [...] }] JSON dizisi olarak.
     */
    suspend fun send(systemPrompt: String, history: JSONArray): GeminiResult = withContext(Dispatchers.IO) {
        val body = JSONObject()
        body.put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
        body.put("contents", history)

        val tools = JSONObject().put("function_declarations", ToolDeclarations.all())
        body.put("tools", JSONArray().put(tools))

        val request = Request.Builder()
            .url("$baseUrl?key=$apiKey")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { resp ->
            val bodyStr = resp.body?.string() ?: ""
            if (!resp.isSuccessful) {
                return@withContext GeminiResult("JARVIS API hatasi: ${resp.code} $bodyStr", null)
            }

            val json = JSONObject(bodyStr)
            val candidates = json.optJSONArray("candidates") ?: return@withContext GeminiResult("Yanit alinamadi.", null)
            if (candidates.length() == 0) return@withContext GeminiResult("Yanit alinamadi.", null)

            val content = candidates.getJSONObject(0).optJSONObject("content")
            val parts = content?.optJSONArray("parts") ?: JSONArray()

            var text: String? = null
            var fn: Pair<String, JSONObject>? = null

            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                if (part.has("text")) {
                    text = (text ?: "") + part.getString("text")
                }
                if (part.has("functionCall")) {
                    val fc = part.getJSONObject("functionCall")
                    val name = fc.getString("name")
                    val args = fc.optJSONObject("args") ?: JSONObject()
                    fn = name to args
                }
            }

            GeminiResult(text, fn)
        }
    }
}
