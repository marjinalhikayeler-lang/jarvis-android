package com.alp.jarvis.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * JARVIS Windows'ta google-genai SDK'siyla Gemini Live'a baglaniyordu.
 * Android'de aynisini standart Gemini REST API (generateContent) +
 * function calling ile yapiyoruz: STT metni buraya gelir, model bir
 * arac cagirmak isterse ("functionCall") onu MainViewModel isler ve
 * sonucu tekrar modele geri gonderir.
 */
class GeminiClient(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val model = "gemini-3.6-flash"
    private val baseUrl = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"

    data class GeminiResult(
        val text: String?,
        val functionCall: Pair<String, JSONObject>?, // name, args
        val functionCallId: String?,
        val rawModelParts: JSONArray // orijinal model "parts" dizisi — id/thoughtSignature gibi
                                      // alanları kaybetmeden aynen geri gönderebilmek için saklanır
    )

    /**
     * history: onceki mesajlar [{role: "user"/"model", parts: [...] }] JSON dizisi olarak.
     * Gemini tarafinda gecici (5xx) hatalar olabiliyor; bu durumda kisa bir
     * bekleme ile 1 kez daha deniyoruz, kullaniciya hemen hata gostermek yerine.
     */
    suspend fun send(systemPrompt: String, history: JSONArray): GeminiResult = withContext(Dispatchers.IO) {
        var lastResult = trySend(systemPrompt, history)
        if (lastResult.text?.contains("JARVIS API hatasi: 5") == true) {
            kotlinx.coroutines.delay(800)
            lastResult = trySend(systemPrompt, history)
        }
        lastResult
    }

    private fun trySend(systemPrompt: String, history: JSONArray): GeminiResult {
        val body = JSONObject()
        body.put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
        body.put("contents", history)

        val tools = JSONObject().put("function_declarations", ToolDeclarations.all())
        body.put("tools", JSONArray().put(tools))

        val request = Request.Builder()
            .url("$baseUrl?key=$apiKey")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { resp ->
            val bodyStr = resp.body?.string() ?: ""
            if (!resp.isSuccessful) {
                return GeminiResult("JARVIS API hatasi: ${resp.code} $bodyStr", null, null, JSONArray())
            }

            val json = JSONObject(bodyStr)
            val candidates = json.optJSONArray("candidates") ?: return GeminiResult("Yanit alinamadi.", null, null, JSONArray())
            if (candidates.length() == 0) return GeminiResult("Yanit alinamadi.", null, null, JSONArray())

            val content = candidates.getJSONObject(0).optJSONObject("content")
            val parts = content?.optJSONArray("parts") ?: JSONArray()

            var text: String? = null
            var fn: Pair<String, JSONObject>? = null
            var fnId: String? = null

            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                if (part.has("text")) {
                    text = (text ?: "") + part.getString("text")
                }
                if (part.has("functionCall")) {
                    val fc = part.getJSONObject("functionCall")
                    val name = fc.getString("name")
                    val args = fc.optJSONObject("args") ?: JSONObject()
                    fn = name to args
                    fnId = if (fc.has("id")) fc.getString("id") else null
                }
            }

            return GeminiResult(text, fn, fnId, parts)
        }
    }
}
