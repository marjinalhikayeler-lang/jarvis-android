package com.alp.jarvis.voice

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import java.io.ByteArrayOutputStream
import kotlin.math.sqrt

/**
 * Android'in SpeechRecognizer'i bazi cihazlarda (Google uygulamasi
 * kapali/kisitli olanlar) hic calismiyor. Bunun yerine ham sesi kendimiz
 * kaydedip (konusma bitince sessizlik algilaninca otomatik durup)
 * Gemini'ye gonderiyoruz — hicbir Google servisine bagimli degil.
 *
 * Kayit basladiginda konusma baslayana kadar bekler, konusma basladiktan
 * sonra ~1.3 saniye sessizlik olursa otomatik durur (elle "durdur"a
 * basmaya gerek yok — hem mikrofon dugmesi hem "hey jarvis" sonrasi
 * otomatik acilan dinleme icin bu davranis gerekli).
 */
class GeminiAudioRecorder(
    private val noSpeechTimeoutMs: Long = 10000L,
    private val onFinished: (ByteArray?) -> Unit
) {
    private var recorder: AudioRecord? = null
    private var recordingThread: Thread? = null
    private val pcmBuffer = ByteArrayOutputStream()
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile private var recording = false

    private val sampleRate = 16000
    private val channelConfig = AudioFormat.CHANNEL_IN_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT

    private val silenceRmsThreshold = 700.0
    private val silenceHangMs = 1300L
    private val maxDurationMs = 15000L
    private val minDurationMs = 400L

    /** Kaydi baslatir. RECORD_AUDIO izni onceden verilmis olmali. */
    fun start(): Boolean {
        val minBufSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
        if (minBufSize <= 0) return false

        return try {
            recorder = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, channelConfig, audioFormat, minBufSize * 2)
            if (recorder?.state != AudioRecord.STATE_INITIALIZED) {
                recorder?.release(); recorder = null
                return false
            }
            pcmBuffer.reset()
            recording = true
            recorder?.startRecording()

            recordingThread = Thread {
                val shortChunk = ShortArray(minBufSize / 2)
                var speechStarted = false
                var silenceSince = 0L
                val startedAt = System.currentTimeMillis()

                while (recording) {
                    val read = recorder?.read(shortChunk, 0, shortChunk.size) ?: -1
                    if (read > 0) {
                        writeShortsAsBytes(shortChunk, read)

                        val rms = rms(shortChunk, read)
                        val now = System.currentTimeMillis()
                        if (rms > silenceRmsThreshold) {
                            speechStarted = true
                            silenceSince = 0L
                        } else if (speechStarted) {
                            if (silenceSince == 0L) {
                                silenceSince = now
                            } else if (now - silenceSince > silenceHangMs && now - startedAt > minDurationMs) {
                                recording = false
                            }
                        }
                        if (now - startedAt > maxDurationMs) recording = false
                        if (!speechStarted && now - startedAt > noSpeechTimeoutMs) recording = false
                    } else {
                        recording = false
                    }
                }

                try { recorder?.stop(); recorder?.release() } catch (_: Exception) {}
                recorder = null

                val pcm = synchronized(pcmBuffer) { pcmBuffer.toByteArray() }
                val wav = if (pcm.size < sampleRate) null else pcmToWav(pcm, sampleRate)
                mainHandler.post { onFinished(wav) }
            }
            recordingThread?.start()
            true
        } catch (e: SecurityException) {
            false
        } catch (e: Exception) {
            false
        }
    }

    /** Sonuc bildirmeden tamamen iptal eder (ornegin ekran/uygulama kapaniyor). */
    fun cancel() {
        recording = false
        recordingThread = null
        try { recorder?.stop(); recorder?.release() } catch (_: Exception) {}
        recorder = null
    }

    private fun writeShortsAsBytes(chunk: ShortArray, len: Int) {
        val bytes = ByteArray(len * 2)
        for (i in 0 until len) {
            val v = chunk[i].toInt()
            bytes[i * 2] = (v and 0xff).toByte()
            bytes[i * 2 + 1] = ((v shr 8) and 0xff).toByte()
        }
        synchronized(pcmBuffer) { pcmBuffer.write(bytes) }
    }

    private fun rms(chunk: ShortArray, len: Int): Double {
        var sum = 0.0
        for (i in 0 until len) sum += (chunk[i] * chunk[i]).toDouble()
        return sqrt(sum / len)
    }

    private fun pcmToWav(pcm: ByteArray, sampleRate: Int): ByteArray {
        val channels = 1
        val bitsPerSample = 16
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val blockAlign = channels * bitsPerSample / 8
        val out = ByteArrayOutputStream(44 + pcm.size)

        fun writeIntLE(v: Int) {
            out.write(v and 0xff); out.write((v shr 8) and 0xff)
            out.write((v shr 16) and 0xff); out.write((v shr 24) and 0xff)
        }
        fun writeShortLE(v: Int) {
            out.write(v and 0xff); out.write((v shr 8) and 0xff)
        }

        out.write("RIFF".toByteArray()); writeIntLE(36 + pcm.size); out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray()); writeIntLE(16); writeShortLE(1); writeShortLE(channels)
        writeIntLE(sampleRate); writeIntLE(byteRate); writeShortLE(blockAlign); writeShortLE(bitsPerSample)
        out.write("data".toByteArray()); writeIntLE(pcm.size); out.write(pcm)
        return out.toByteArray()
    }
}
