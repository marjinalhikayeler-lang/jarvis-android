package com.alp.jarvis.actions

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Windows suerumundeki actions/sys_info.py karsiligi (pil, saat, tarih).
 * Android sandbox'i genel CPU/RAM bilgisini uygulamalara vermedigi icin
 * o kisim çıkarıldı; pil, saat ve tarih birebir calisir.
 */
object SysInfo {

    fun battery(context: Context): String {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus = context.registerReceiver(null, filter)
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1

        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

        return if (pct >= 0) {
            "Pil durumu: %$pct" + if (isCharging) " (şarj oluyor)" else ""
        } else {
            "Pil bilgisi alınamadı."
        }
    }

    fun time(): String {
        val fmt = SimpleDateFormat("HH:mm", Locale("tr"))
        return "Saat ${fmt.format(Date())}."
    }

    fun date(): String {
        val fmt = SimpleDateFormat("d MMMM yyyy, EEEE", Locale("tr"))
        return "Bugün ${fmt.format(Date())}."
    }
}
