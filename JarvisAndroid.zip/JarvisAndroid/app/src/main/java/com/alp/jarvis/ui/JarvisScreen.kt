package com.alp.jarvis.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alp.jarvis.ChatMessage
import com.alp.jarvis.JarvisState
import kotlin.math.min

private val CBg = Color(0xFF020C0C)
private val CPri = Color(0xFF00D4C0)
private val CMid = Color(0xFF006A62)
private val CDim = Color(0xFF0A2A28)
private val CText = Color(0xFF7DFFF6)
private val CPanel = Color(0xFF030F0F)
private val CGreen = Color(0xFF00FF88)
private val CRed = Color(0xFFFF3344)
private val CGold = Color(0xFFFFCC00)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisScreen(
    state: JarvisState,
    messages: List<ChatMessage>,
    apiKeySet: Boolean,
    onMicClick: () -> Unit,
    onSendText: (String) -> Unit,
    onSaveApiKey: (String) -> Unit
) {
    var showSettings by remember { mutableStateOf(!apiKeySet) }
    var textInput by remember { mutableStateOf("") }

    LaunchedEffect(apiKeySet) {
        if (!apiKeySet) showSettings = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CBg)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {

            // Top bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "J.A.R.V.I.S",
                        color = CPri,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 4.sp
                    )
                    Text(
                        "VOICE CORE · Android",
                        color = CMid,
                        fontSize = 11.sp,
                        letterSpacing = 2.sp
                    )
                }
                IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Filled.Settings, contentDescription = "Ayarlar", tint = CMid)
                }
            }

            // Ring visualizer
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp),
                contentAlignment = Alignment.Center
            ) {
                JarvisRing(state = state)
                Text(
                    stateLabel(state),
                    color = CText,
                    fontSize = 13.sp,
                    letterSpacing = 2.sp,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp)
                )
            }

            // Chat log
            val listState = rememberLazyListState()
            LaunchedEffect(messages.size) {
                if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { msg -> ChatBubble(msg) }
                item { Spacer(Modifier.height(8.dp)) }
            }

            // Input row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Jarvis'e yaz...", color = CMid) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = CText,
                        unfocusedTextColor = CText,
                        focusedBorderColor = CPri,
                        unfocusedBorderColor = CMid,
                        cursorColor = CPri,
                        focusedContainerColor = CPanel,
                        unfocusedContainerColor = CPanel
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    singleLine = true
                )

                IconButton(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            onSendText(textInput)
                            textInput = ""
                        }
                    },
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(CDim)
                ) {
                    Icon(Icons.Filled.Send, contentDescription = "Gönder", tint = CPri)
                }

                IconButton(
                    onClick = onMicClick,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(if (state == JarvisState.LISTENING) CRed.copy(alpha = 0.25f) else CDim)
                ) {
                    Icon(
                        Icons.Filled.Mic,
                        contentDescription = "Mikrofon",
                        tint = if (state == JarvisState.LISTENING) CRed else CPri
                    )
                }
            }
        }
    }

    if (showSettings) {
        ApiKeyDialog(
            initiallySet = apiKeySet,
            onDismiss = { if (apiKeySet) showSettings = false },
            onSave = { key ->
                onSaveApiKey(key)
                showSettings = false
            }
        )
    }
}

@Composable
private fun stateLabel(state: JarvisState) = when (state) {
    JarvisState.IDLE -> "HAZIR"
    JarvisState.LISTENING -> "DİNLİYORUM..."
    JarvisState.THINKING -> "DÜŞÜNÜYOR..."
    JarvisState.SPEAKING -> "KONUŞUYOR"
    JarvisState.ERROR -> "HATA"
}

@Composable
fun JarvisRing(state: JarvisState) {
    val infinite = rememberInfiniteTransition(label = "ring")
    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    JarvisState.THINKING -> 1200
                    JarvisState.LISTENING -> 2500
                    else -> 6000
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val pulse by infinite.animateFloat(
        initialValue = 0.85f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val color = when (state) {
        JarvisState.LISTENING -> CRed
        JarvisState.THINKING -> CGold
        JarvisState.SPEAKING -> CGreen
        JarvisState.ERROR -> CRed
        JarvisState.IDLE -> CPri
    }

    Canvas(modifier = Modifier.size(180.dp)) {
        val strokeWidth = 4.dp.toPx()
        val radiusOuter = min(size.width, size.height) / 2f - strokeWidth
        val radiusMid = radiusOuter * 0.75f
        val radiusInner = radiusOuter * 0.5f

        rotate(rotation) {
            drawArc(
                color = color.copy(alpha = 0.9f),
                startAngle = 0f,
                sweepAngle = 260f,
                useCenter = false,
                topLeft = androidx.compose.ui.geometry.Offset(center.x - radiusOuter, center.y - radiusOuter),
                size = androidx.compose.ui.geometry.Size(radiusOuter * 2, radiusOuter * 2),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth)
            )
        }
        rotate(-rotation * 1.4f) {
            drawArc(
                color = CMid.copy(alpha = 0.8f),
                startAngle = 40f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = androidx.compose.ui.geometry.Offset(center.x - radiusMid, center.y - radiusMid),
                size = androidx.compose.ui.geometry.Size(radiusMid * 2, radiusMid * 2),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth)
            )
        }
        drawCircle(
            color = color.copy(alpha = 0.15f * pulse),
            radius = radiusInner * pulse
        )
        drawCircle(
            color = color,
            radius = 6.dp.toPx()
        )
    }
}

@Composable
private fun ChatBubble(msg: ChatMessage) {
    val isUser = msg.role == "user"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .background(
                    if (isUser) CDim else CPanel,
                    shape = RoundedCornerShape(14.dp)
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .widthIn(max = 280.dp)
        ) {
            Text(
                msg.text,
                color = if (isUser) CText else CPri,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
private fun ApiKeyDialog(
    initiallySet: Boolean,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var key by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CPanel,
        title = { Text("Gemini API Anahtarı", color = CPri) },
        text = {
            Column {
                Text(
                    "aistudio.google.com adresinden ücretsiz bir API anahtarı alıp buraya yapıştır.",
                    color = CText,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    placeholder = { Text("API anahtarı", color = CMid) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = CText,
                        unfocusedTextColor = CText,
                        focusedBorderColor = CPri,
                        unfocusedBorderColor = CMid,
                        cursorColor = CPri
                    )
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { if (key.isNotBlank()) onSave(key) }) {
                Text("Kaydet", color = CGreen)
            }
        },
        dismissButton = {
            if (initiallySet) {
                TextButton(onClick = onDismiss) { Text("Kapat", color = CMid) }
            }
        }
    )
}
