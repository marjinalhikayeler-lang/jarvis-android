package com.alp.jarvis.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alp.jarvis.ChatMessage
import com.alp.jarvis.JarvisState
import com.alp.jarvis.camera.CameraPreviewView
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

// v3 (Windows) renk paleti — ui.py'deki C_* sabitleriyle birebir aynı
private val CBg = Color(0xFF020C0C)
private val CPri = Color(0xFF00D4C0)
private val CMid = Color(0xFF006A62)
private val CDim = Color(0xFF0A2A28)
private val CText = Color(0xFF7DFFF6)
private val CPanel = Color(0xFF030F0F)
private val CGreen = Color(0xFF00FF88)   // LISTENING
private val CBlue = Color(0xFF4488FF)    // SPEAKING
private val CRed = Color(0xFFFF3344)     // ERROR / INITIALISING
private val CGold = Color(0xFFFFCC00)    // THINKING

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisScreen(
    state: JarvisState,
    messages: List<ChatMessage>,
    apiKeySet: Boolean,
    cameraOpen: Boolean,
    onMicClick: () -> Unit,
    onSendText: (String) -> Unit,
    onSaveApiKey: (String) -> Unit,
    onCameraToggle: (Boolean) -> Unit
) {
    var showSettings by remember { mutableStateOf(!apiKeySet) }
    var textInput by remember { mutableStateOf("") }
    var useFrontCamera by remember { mutableStateOf(false) }

    LaunchedEffect(apiKeySet) {
        if (!apiKeySet) showSettings = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CBg)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {

            // Top bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "J.A.R.V.I.S",
                        color = CPri,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 4.sp
                    )
                    Text(
                        "VOICE CORE · Android",
                        color = CMid,
                        fontSize = 11.sp,
                        letterSpacing = 2.sp
                    )
                }
                IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Filled.Settings, contentDescription = "Ayarlar", tint = CMid)
                }
            }

            // Orb / kamera alanı
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (cameraOpen) {
                    CameraPreviewView(modifier = Modifier.fillMaxSize(), useFrontCamera = useFrontCamera)

                    // Kamera açıkken de durumu gösteren küçük bir halka, sağ üstte
                    Box(modifier = Modifier.align(Alignment.TopEnd).padding(10.dp)) {
                        JarvisOrb(state = state, sizeDp = 46.dp, richness = 0.0f)
                    }

                    IconButton(
                        onClick = { useFrontCamera = !useFrontCamera },
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(CBg.copy(alpha = 0.55f))
                    ) {
                        Text("⟲", color = CPri, fontSize = 18.sp)
                    }
                } else {
                    JarvisOrb(state = state, sizeDp = 190.dp, richness = 1.0f)
                }

                Text(
                    stateLabel(state),
                    color = CText,
                    fontSize = 13.sp,
                    letterSpacing = 2.sp,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp)
                )
            }

            // Chat log
            val listState = rememberLazyListState()
            LaunchedEffect(messages.size) {
                if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { msg -> ChatBubble(msg) }
                item { Spacer(Modifier.height(8.dp)) }
            }

            // Input row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Jarvis'e yaz...", color = CMid) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = CText,
                        unfocusedTextColor = CText,
                        focusedBorderColor = CPri,
                        unfocusedBorderColor = CMid,
                        cursorColor = CPri,
                        focusedContainerColor = CPanel,
                        unfocusedContainerColor = CPanel
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    singleLine = true
                )

                IconButton(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            onSendText(textInput)
                            textInput = ""
                        }
                    },
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(CDim)
                ) {
                    Icon(Icons.Filled.Send, contentDescription = "Gönder", tint = CPri)
                }

                IconButton(
                    onClick = { onCameraToggle(!cameraOpen) },
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(if (cameraOpen) CBlue.copy(alpha = 0.25f) else CDim)
                ) {
                    Icon(
                        Icons.Filled.PhotoCamera,
                        contentDescription = "Kamera",
                        tint = if (cameraOpen) CBlue else CPri
                    )
                }

                IconButton(
                    onClick = onMicClick,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(if (state == JarvisState.LISTENING) CGreen.copy(alpha = 0.25f) else CDim)
                ) {
                    Icon(
                        Icons.Filled.Mic,
                        contentDescription = "Mikrofon",
                        tint = if (state == JarvisState.LISTENING) CGreen else CPri
                    )
                }
            }
        }
    }

    if (showSettings) {
        ApiKeyDialog(
            initiallySet = apiKeySet,
            onDismiss = { if (apiKeySet) showSettings = false },
            onSave = { key ->
                onSaveApiKey(key)
                showSettings = false
            }
        )
    }
}

@Composable
private fun stateLabel(state: JarvisState) = when (state) {
    JarvisState.IDLE -> "HAZIR"
    JarvisState.LISTENING -> "DİNLİYORUM..."
    JarvisState.THINKING -> "DÜŞÜNÜYOR..."
    JarvisState.SPEAKING -> "KONUŞUYOR"
    JarvisState.ERROR -> "HATA"
}

private fun stateRgb(state: JarvisState): Color = when (state) {
    JarvisState.SPEAKING -> CBlue
    JarvisState.THINKING -> CGold
    JarvisState.ERROR -> CRed
    JarvisState.LISTENING, JarvisState.IDLE -> CGreen
}

private data class OrbParticle(
    val angle: Float,
    val speed: Float,
    val orbit: Float,
    val size: Float,
    val phase: Float,
    val wobble: Float,
    val depth: Float
)

/**
 * v3'teki (Windows) _draw_orb() rutininin sadelestirilmis Compose karsiligi:
 * katmanli yapisal cemberler + parlama + donen segment yaylar + yorungede
 * doenen parcaciklar. richness 1.0 = tam efekt (ana ekran), 0.0 = sade
 * (kamera modundaki kucuk gosterge).
 */
@Composable
fun JarvisOrb(state: JarvisState, sizeDp: androidx.compose.ui.unit.Dp, richness: Float = 1f) {
    val color = stateRgb(state)
    val particleCount = if (richness > 0.5f) 42 else 0

    val particles = remember {
        List(particleCount) {
            OrbParticle(
                angle = Random.nextFloat() * 6.2832f,
                speed = (Random.nextFloat() * 0.6f + 0.2f) * if (Random.nextBoolean()) 1f else -1f,
                orbit = Random.nextFloat() * 0.7f + 0.3f,
                size = Random.nextFloat() * 2.6f + 1.2f,
                phase = Random.nextFloat() * 6.2832f,
                wobble = Random.nextFloat() * 0.08f + 0.02f,
                depth = Random.nextFloat()
            )
        }
    }

    var tMillis by remember { mutableStateOf(0L) }
    LaunchedEffect(Unit) {
        var start = -1L
        while (true) {
            withFrameMillis { now ->
                if (start < 0) start = now
                tMillis = now - start
            }
        }
    }
    val t = tMillis / 16f

    val activity = when (state) {
        JarvisState.SPEAKING -> 1.0f
        JarvisState.THINKING -> 0.62f
        JarvisState.LISTENING -> 0.78f
        JarvisState.ERROR -> 0.62f
        JarvisState.IDLE -> 0.26f
    }
    val speakPulse = 1f + (if (state == JarvisState.SPEAKING) 0.12f * sin(t * 0.05f) else 0.02f * sin(t * 0.03f))

    Canvas(modifier = Modifier.size(sizeDp)) {
        val fw = min(size.width, size.height) * speakPulse
        val fieldR = fw * 0.49f
        val innerR = fw * 0.34f

        // Buyuk dis parlama
        if (richness > 0.5f) {
            for (i in 8 downTo 1) {
                val frac = i / 8f
                val rr = fieldR * (1.02f + 0.05f * frac)
                val alpha = (0.05f * frac * (0.5f + activity))
                drawCircle(color = color.copy(alpha = alpha.coerceIn(0f, 1f)), radius = rr, style = Stroke(width = 2.5f))
            }
        }

        // Yapisal cemberler
        val ringSpecs = listOf(1.00f to 0.34f, 0.90f to 0.24f, 0.76f to 0.18f, 0.62f to 0.12f)
        for ((frac, a) in ringSpecs) {
            drawCircle(
                color = color.copy(alpha = (a * (0.4f + activity)).coerceIn(0f, 1f)),
                radius = fieldR * frac,
                style = Stroke(width = if (frac > 0.8f) 2f else 1.2f)
            )
        }

        // Donen segment yaylar
        val arcR1 = fieldR * 0.96f
        val arcR2 = fieldR * 0.78f
        val spin1 = (t * 0.6f) % 360f
        val spin2 = (-t * 0.9f) % 360f
        drawArc(
            color = color.copy(alpha = 0.85f),
            startAngle = spin1,
            sweepAngle = if (state == JarvisState.SPEAKING) 52f else 34f,
            useCenter = false,
            topLeft = Offset(center.x - arcR1, center.y - arcR1),
            size = androidx.compose.ui.geometry.Size(arcR1 * 2, arcR1 * 2),
            style = Stroke(width = 3f)
        )
        drawArc(
            color = color.copy(alpha = 0.55f),
            startAngle = spin2 + 28f,
            sweepAngle = if (state == JarvisState.LISTENING) 64f else 40f,
            useCenter = false,
            topLeft = Offset(center.x - arcR2, center.y - arcR2),
            size = androidx.compose.ui.geometry.Size(arcR2 * 2, arcR2 * 2),
            style = Stroke(width = 3f)
        )

        // Yorungedeki parcaciklar
        val fieldLimit = innerR * (if (state == JarvisState.SPEAKING) 1.36f else 1.05f)
        for (p in particles) {
            val speedMult = when (state) {
                JarvisState.SPEAKING -> 3.0f
                JarvisState.LISTENING -> 2.0f
                else -> 1.1f
            }
            val angle = p.angle + t * p.speed * speedMult * 0.02f
            val wobbleAmt = 1f + 0.2f * sin(t * p.wobble + p.phase)
            val orbit = fieldLimit * p.orbit * wobbleAmt
            val x = center.x + cos(angle) * orbit
            val y = center.y + sin(angle) * orbit * 0.9f
            val alpha = ((0.15f + 0.5f * p.depth) * (0.3f + activity * 0.8f)).coerceIn(0f, 1f)
            drawCircle(color = color.copy(alpha = alpha), radius = p.size, center = Offset(x, y))
        }

        // Merkez bosluk (lens gorunumunu kirar)
        drawCircle(color = CBg, radius = innerR * 0.12f, center = center)
        // Merkez nokta
        drawCircle(color = color, radius = fw * 0.018f, center = center)
    }
}

@Composable
private fun ChatBubble(msg: ChatMessage) {
    val isUser = msg.role == "user"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .background(
                    if (isUser) CDim else CPanel,
                    shape = RoundedCornerShape(14.dp)
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .widthIn(max = 280.dp)
        ) {
            Text(
                msg.text,
                color = if (isUser) CText else CPri,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
private fun ApiKeyDialog(
    initiallySet: Boolean,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var key by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CPanel,
        title = { Text("Gemini API Anahtarı", color = CPri) },
        text = {
            Column {
                Text(
                    "aistudio.google.com adresinden ücretsiz bir API anahtarı alıp buraya yapıştır.",
                    color = CText,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    placeholder = { Text("API anahtarı", color = CMid) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = CText,
                        unfocusedTextColor = CText,
                        focusedBorderColor = CPri,
                        unfocusedBorderColor = CMid,
                        cursorColor = CPri
                    )
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { if (key.isNotBlank()) onSave(key) }) {
                Text("Kaydet", color = CGreen)
            }
        },
        dismissButton = {
            if (initiallySet) {
                TextButton(onClick = onDismiss) { Text("Kapat", color = CMid) }
            }
        }
    )
}
