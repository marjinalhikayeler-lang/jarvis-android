package com.alp.jarvis.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

/**
 * Windows suerumundeki actions/tts.py karsiligi.
 * Android'in yerlesik TextToSpeech motorunu kullanir.
 */
class SpeechOutput(
    context: Context,
    private val onSpeakingChange: (Boolean) -> Unit
) {
    private var tts: TextToSpeech? = null
    private var ready = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("tr", "TR")
                ready = true
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { onSpeakingChange(true) }
            override fun onDone(utteranceId: String?) { onSpeakingChange(false) }
            override fun onError(utteranceId: String?) { onSpeakingChange(false) }
        })
    }

    fun speak(text: String) {
        if (!ready || text.isBlank()) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.shutdown()
    }
}
