package com.alp.jarvis.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * SpeechInput (mikrofon butonu, tek seferlik dinleme) ile ayni API'yi
 * kullanir ama sonucundan/hatasindan bagimsiz olarak kendini surekli
 * yeniden baslatir. Arka plan servisinde "Jarvis..." komutlarini
 * yakalamak icin kullanilir.
 */
class ContinuousSpeechListener(
    private val context: Context,
    private val onHeard: (String) -> Unit
) {
    private var recognizer: SpeechRecognizer? = null
    private var running = false
    private val handler = Handler(Looper.getMainLooper())

    fun start() {
        if (running) return
        running = true
        handler.post { listenOnce() }
    }

    fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
    }

    private fun listenOnce() {
        if (!running) return
        if (!SpeechRecognizer.isRecognitionAvailable(context)) return

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}

                override fun onError(error: Int) {
                    if (!running) return
                    handler.postDelayed({ listenOnce() }, 700)
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val wakePick = matches?.firstOrNull { it.contains("jarvis", ignoreCase = true) }
                    (wakePick ?: matches?.firstOrNull())?.let { onHeard(it) }
                    if (running) handler.postDelayed({ listenOnce() }, 300)
                }

                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        }

        try {
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            if (running) handler.postDelayed({ listenOnce() }, 1000)
        }
    }
}
