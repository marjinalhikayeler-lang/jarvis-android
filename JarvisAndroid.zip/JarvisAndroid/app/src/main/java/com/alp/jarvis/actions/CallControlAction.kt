package com.alp.jarvis.actions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat
import com.alp.jarvis.core.CallPolicy

object CallControlAction {

    fun answerCall(context: Context): String {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED
        if (!granted) return "Aramayı açmak için 'Telefon Aramalarını Yönet' iznini vermen gerekiyor."
        return try {
            val tm = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.acceptRingingCall()
            "Arama açıldı."
        } catch (e: Exception) {
            "Aramayı açamadım: ${e.message}"
        }
    }

    fun setAutoReject(enabled: Boolean): String {
        CallPolicy.autoReject = enabled
        return if (enabled)
            "Bundan sonra gelen aramaları otomatik reddedeceğim. Bunun çalışması için JARVIS'i telefonun arama filtreleme uygulaması olarak seçmen gerekebilir, Ayarlar'dan yapabilirsin."
        else
            "Gelen aramalar artık normal çalacak."
    }
}
