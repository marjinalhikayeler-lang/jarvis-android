package com.alp.jarvis.core

import android.content.Context
import com.alp.jarvis.actions.BrowserAction
import com.alp.jarvis.actions.CalendarAction
import com.alp.jarvis.actions.CallControlAction
import com.alp.jarvis.actions.OpenApp
import com.alp.jarvis.actions.PhoneAction
import com.alp.jarvis.actions.SpotifyAction
import com.alp.jarvis.actions.SysInfo
import com.alp.jarvis.actions.UiAutomationAction
import com.alp.jarvis.actions.VolumeAction
import com.alp.jarvis.actions.Weather
import com.alp.jarvis.actions.WhatsAppAction
import com.alp.jarvis.camera.CameraFrameHolder
import com.alp.jarvis.voice.AudioPlayer
import com.alp.jarvis.voice.SpeechOutput
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class JarvisState { IDLE, LISTENING, THINKING, SPEAKING, ERROR }

data class ChatMessage(val role: String, val text: String) // role: "user" | "jarvis"

/**
 * JARVIS'in konusma/aksiyon mantiginin tamami burada toplanir. Hem
 * MainViewModel (ekran acikken) hem JarvisBackgroundService (arka planda,
 * "Jarvis ..." komutlariyla) ayni ornegi (bkz. JarvisEngineHolder)
 * kullanir — boylece konusma gecmisi kesintisiz devam eder.
 */
class JarvisEngine(private val appContext: Context) {

    interface Listener {
        fun onState(state: JarvisState) {}
        fun onMessage(msg: ChatMessage) {}
    }

    /** UI baglandiginda set edilir; arka planda calisirken null olabilir. */
    var listener: Listener? = null

    private val settings = SettingsStore(appContext)
    private val memory = MemoryManager(appContext)
    private var geminiClient: GeminiClient? = null
    private var apiKey: String? = null
    private val history = JSONArray()

    @Volatile
    var cameraOpen = false
        private set

    private val audioPlayer by lazy { AudioPlayer(appContext) }
    private var androidTts: SpeechOutput? = null
    private var voiceName: String = "Charon"

    private suspend fun ensureReady() {
        if (apiKey == null) {
            val key = settings.getApiKey()
            if (!key.isNullOrBlank()) {
                apiKey = key
                geminiClient = GeminiClient(key)
            }
            voiceName = settings.getVoice()
            CallPolicy.autoReject = settings.getCallAutoReject()
        }
    }

    suspend fun onVoiceUpdated(voice: String) {
        voiceName = voice
        settings.setVoice(voice)
    }

    fun currentApiKey(): String? = apiKey
    fun currentVoice(): String = voiceName

    /** Aktivite yeniden bir API anahtari kaydettiginde cagrilir. */
    suspend fun onApiKeyUpdated(key: String) {
        apiKey = key
        geminiClient = GeminiClient(key)
        settings.setApiKey(key)
    }

    fun isApiKeyReady() = apiKey != null

    suspend fun getBackgroundListeningPref(): Boolean = settings.getBackgroundListening()
    suspend fun setBackgroundListeningPref(enabled: Boolean) = settings.setBackgroundListening(enabled)

    fun setCameraOpen(open: Boolean) {
        cameraOpen = open
        if (!open) CameraFrameHolder.clear()
    }

    suspend fun preload() = ensureReady()

    private val wakeWords = listOf("hey jarvis", "jarvis")

    private fun stripWakeWord(text: String): String {
        val trimmed = text.trim()
        val lower = trimmed.lowercase(Locale("tr"))
        for (w in wakeWords.sortedByDescending { it.length }) {
            if (lower.startsWith(w)) {
                return trimmed.substring(w.length).trim(' ', ',', '.', '!', '?', ':')
            }
        }
        return trimmed
    }

    private fun isBareWakeWord(text: String): Boolean {
        val cleaned = text.trim().trim('.', ',', '!', '?').lowercase(Locale("tr"))
        return cleaned == "jarvis" || cleaned == "hey jarvis"
    }

    /**
     * Sesle duyulan bir metni isler. requireWakeWord=true ise (arka plan
     * surekli dinleme) "jarvis" onekiyle baslamayan cumleler yoksayilir.
     * requireWakeWord=false ise (uygulama icindeki mikrofon butonu, kullanici
     * zaten bilincli olarak dokundugu icin) onek sart degildir ama varsa
     * temizlenir. Sadece "jarvis"/"hey jarvis" denirse kisa bir onay verilir.
     * Donen deger: bir komut islendi/onay verildi mi (cagiran taraf, ornegin
     * mikrofonu tekrar acmak icin kullanabilir).
     */
    suspend fun handleHeardSpeech(rawText: String, requireWakeWord: Boolean): Boolean {
        if (rawText.isBlank()) return false

        if (isBareWakeWord(rawText)) {
            val ack = "Sizi dinliyorum, efendim."
            listener?.onMessage(ChatMessage("jarvis", ack))
            listener?.onState(JarvisState.SPEAKING)
            speak(ack)
            return true
        }

        val stripped = stripWakeWord(rawText)
        val hadWakeWord = stripped != rawText.trim()

        if (requireWakeWord && !hadWakeWord) {
            return false // arka planda "jarvis" denmedi, komut degil - yoksay
        }

        handleUtterance(stripped.ifBlank { rawText })
        return true
    }

    suspend fun handleUtterance(text: String) {
        ensureReady()
        if (text.isBlank()) return

        listener?.onMessage(ChatMessage("user", text))
        listener?.onState(JarvisState.THINKING)

        val userParts = JSONArray().put(JSONObject().put("text", text))
        if (cameraOpen) {
            CameraFrameHolder.latestJpeg?.let { jpeg ->
                val b64 = android.util.Base64.encodeToString(jpeg, android.util.Base64.NO_WRAP)
                userParts.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject().put("mime_type", "image/jpeg").put("data", b64)
                    )
                )
            }
        }
        history.put(JSONObject().put("role", "user").put("parts", userParts))

        runTurn(depth = 0)
    }

    private suspend fun runTurn(depth: Int) {
        val client = geminiClient
        if (client == null) {
            listener?.onState(JarvisState.ERROR)
            val msg = "Önce Gemini API anahtarını girmelisin."
            listener?.onMessage(ChatMessage("jarvis", msg))
            speak(msg)
            return
        }
        if (depth > 4) {
            listener?.onState(JarvisState.IDLE)
            return
        }

        val now = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).format(Date())
        val memoryBlock = memory.formatForPrompt()
        val prompt = SystemPrompt.build(now, memoryBlock)

        val result = client.send(prompt, history)

        if (result.functionCall != null) {
            val (name, args) = result.functionCall

            history.put(JSONObject().put("role", "model").put("parts", result.rawModelParts))

            val actionResult = executeAction(name, args)

            val responsePart = JSONObject().put("name", name)
                .put("response", JSONObject().put("result", actionResult))
            if (result.functionCallId != null) responsePart.put("id", result.functionCallId)

            history.put(
                JSONObject().put("role", "user").put(
                    "parts", JSONArray().put(JSONObject().put("functionResponse", responsePart))
                )
            )

            runTurn(depth + 1)
            return
        }

        val text = result.text ?: "Bir şey söyleyemedim, tekrar dener misin?"
        history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", text))))

        listener?.onMessage(ChatMessage("jarvis", text))
        listener?.onState(JarvisState.SPEAKING)
        speak(text)
    }

    private suspend fun speak(text: String) {
        val key = apiKey
        if (key != null) {
            val wav = GeminiTts.synthesize(key, text, voiceName)
            if (wav != null) {
                audioPlayer.playWav(wav) { listener?.onState(JarvisState.IDLE) }
                return
            }
        }
        if (androidTts == null) {
            androidTts = SpeechOutput(appContext) { speaking ->
                if (!speaking) listener?.onState(JarvisState.IDLE)
            }
        }
        androidTts?.speak(text)
    }

    private suspend fun executeAction(name: String, args: JSONObject): String {
        return try {
            when (name) {
                "open_app" -> OpenApp.open(appContext, args.optString("app_name"))
                "sys_info" -> when (args.optString("kind")) {
                    "battery" -> SysInfo.battery(appContext)
                    "date" -> SysInfo.date()
                    else -> SysInfo.time()
                }
                "get_weather" -> Weather.summary(args.optString("location"))
                "get_calendar_events" -> CalendarAction.getEvents(appContext, args.optString("query"))
                "add_calendar_event" -> CalendarAction.addEvent(
                    appContext, args.optString("title"), args.optString("start_iso"),
                    args.optString("end_iso").ifBlank { null }
                )
                "open_browser" -> BrowserAction.openBrowser(appContext, args.optString("mode"), args.optString("query"))
                "open_youtube" -> BrowserAction.openYoutube(appContext, args.optString("query"))
                "save_memory" -> memory.save(args.optString("category"), args.optString("key"), args.optString("value"))
                "delete_memory" -> memory.delete(args.optString("match_text"))
                "open_camera" -> { setCameraOpen(true); "Kamera açıldı, seni görüyorum." }
                "close_camera" -> { setCameraOpen(false); "Kamera kapatıldı." }
                "set_volume" -> VolumeAction.setVolumePercent(appContext, args.optDouble("percent", 50.0).toInt())
                "adjust_volume" -> VolumeAction.adjustVolumePercent(appContext, args.optDouble("delta_percent", 0.0).toInt())
                "send_whatsapp_message" -> WhatsAppAction.sendMessage(appContext, args.optString("contact_name"), args.optString("message"))
                "call_contact" -> {
                    val via = args.optString("via", "phone")
                    if (via == "whatsapp") WhatsAppAction.call(appContext, args.optString("contact_name"))
                    else PhoneAction.call(appContext, args.optString("contact_name"))
                }
                "open_spotify" -> SpotifyAction.playSearch(appContext, args.optString("query"))
                "answer_call" -> CallControlAction.answerCall(appContext)
                "set_call_auto_reject" -> {
                    val enabled = args.optBoolean("enabled", false)
                    settings.setCallAutoReject(enabled)
                    CallControlAction.setAutoReject(enabled)
                }
                "ui_tap" -> UiAutomationAction.tap(appContext, args.optString("text"))
                "ui_type" -> UiAutomationAction.type(appContext, args.optString("text"))
                "ui_scroll" -> UiAutomationAction.scroll(appContext, args.optString("direction", "down") == "down")
                "ui_back" -> UiAutomationAction.back(appContext)
                "ui_home" -> UiAutomationAction.home(appContext)
                else -> "Bilinmeyen araç: $name"
            }
        } catch (e: Exception) {
            "Aracı çalıştırırken hata oluştu: ${e.message}"
        }
    }
}
