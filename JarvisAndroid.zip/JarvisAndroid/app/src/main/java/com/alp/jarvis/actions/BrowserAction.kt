package com.alp.jarvis.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.net.URLEncoder

/**
 * Windows suerumundeki actions/browser.py ve media.py (YouTube kismi)
 * karsiligi. Android Intent sistemi ile tarayici/YouTube acilir.
 */
object BrowserAction {

    fun openBrowser(context: Context, mode: String, query: String): String {
        val url = if (mode == "url") {
            if (query.startsWith("http")) query else "https://$query"
        } else {
            "https://www.google.com/search?q=" + URLEncoder.encode(query, "UTF-8")
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return if (mode == "url") "$query açılıyor." else "\"$query\" aranıyor."
    }

    fun openYoutube(context: Context, query: String): String {
        val url = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(query, "UTF-8")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return "YouTube'da \"$query\" açılıyor."
    }
}
