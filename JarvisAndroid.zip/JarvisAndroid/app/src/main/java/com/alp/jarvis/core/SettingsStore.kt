package com.alp.jarvis.core

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.first

/**
 * Windows suerumundeki app_config.py karsiligi — Gemini API anahtarini,
 * secili sesi ve arka plan dinleme tercihini cihazda kalici saklar.
 */
class SettingsStore(private val context: Context) {
    private val API_KEY = stringPreferencesKey("gemini_api_key")
    private val VOICE = stringPreferencesKey("gemini_voice")
    private val BACKGROUND_LISTENING = booleanPreferencesKey("background_listening")
    private val CALL_AUTO_REJECT = booleanPreferencesKey("call_auto_reject")

    suspend fun getApiKey(): String? {
        return context.dataStore.data.first()[API_KEY]
    }

    suspend fun setApiKey(key: String) {
        context.dataStore.edit { it[API_KEY] = key }
    }

    suspend fun getVoice(): String {
        return context.dataStore.data.first()[VOICE] ?: "Charon"
    }

    suspend fun setVoice(voice: String) {
        context.dataStore.edit { it[VOICE] = voice }
    }

    suspend fun getBackgroundListening(): Boolean {
        return context.dataStore.data.first()[BACKGROUND_LISTENING] ?: false
    }

    suspend fun setBackgroundListening(enabled: Boolean) {
        context.dataStore.edit { it[BACKGROUND_LISTENING] = enabled }
    }

    suspend fun getCallAutoReject(): Boolean {
        return context.dataStore.data.first()[CALL_AUTO_REJECT] ?: false
    }

    suspend fun setCallAutoReject(enabled: Boolean) {
        context.dataStore.edit { it[CALL_AUTO_REJECT] = enabled }
    }
}
