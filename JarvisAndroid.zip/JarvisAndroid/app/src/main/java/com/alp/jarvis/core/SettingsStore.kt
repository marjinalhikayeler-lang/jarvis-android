package com.alp.jarvis.core

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.first

/**
 * Windows suerumundeki app_config.py karsiligi — sadece Gemini API
 * anahtarini cihazda sakliyor (config/api_keys.json yerine DataStore).
 */
class SettingsStore(private val context: Context) {
    private val API_KEY = stringPreferencesKey("gemini_api_key")

    suspend fun getApiKey(): String? {
        return context.dataStore.data.first()[API_KEY]
    }

    suspend fun setApiKey(key: String) {
        context.dataStore.edit { it[API_KEY] = key }
    }
}
