package com.alp.jarvis

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.alp.jarvis.core.ChatMessage
import com.alp.jarvis.core.JarvisEngine
import com.alp.jarvis.core.JarvisEngineHolder
import com.alp.jarvis.core.JarvisState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/** Ayarlarda secilebilecek Gemini sesleri (v3'teki VOICES listesiyle ayni). */
val AVAILABLE_VOICES = listOf("Charon", "Puck", "Aoede", "Kore", "Fenrir", "Leda", "Orus", "Zephyr")

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val engine: JarvisEngine = JarvisEngineHolder.get(app)

    private val _state = MutableStateFlow(JarvisState.IDLE)
    val state: StateFlow<JarvisState> = _state

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages

    private val _apiKeySet = MutableStateFlow(false)
    val apiKeySet: StateFlow<Boolean> = _apiKeySet

    private val _cameraOpen = MutableStateFlow(false)
    val cameraOpen: StateFlow<Boolean> = _cameraOpen

    private val _currentVoice = MutableStateFlow("Charon")
    val currentVoice: StateFlow<String> = _currentVoice

    private val _backgroundListening = MutableStateFlow(false)
    val backgroundListening: StateFlow<Boolean> = _backgroundListening

    /** Sesle baslatilan bir konusma bittiginde otomatik mikrofonu tekrar acmak icin. */
    var onAutoRelisten: (() -> Unit)? = null
    private var voiceMode = false

    init {
        engine.listener = object : JarvisEngine.Listener {
            override fun onState(s: JarvisState) {
                _state.value = s
                if (s == JarvisState.IDLE && voiceMode) {
                    onAutoRelisten?.invoke()
                }
            }
            override fun onMessage(msg: ChatMessage) {
                _messages.value = _messages.value + msg
            }
        }
        viewModelScope.launch {
            engine.preload()
            _apiKeySet.value = engine.isApiKeyReady()
            _currentVoice.value = engine.currentVoice()
            _backgroundListening.value = engine.getBackgroundListeningPref()
        }
        _cameraOpen.value = engine.cameraOpen
    }

    /** Ayarlar penceresindeki anahtarin GERCEK durumu (servis basarili baslatildi mi)
     *  MainActivity tarafindan bildirilir; boylece "kapattim ama acik kaldi/tersi" olmaz. */
    fun setBackgroundListeningState(enabled: Boolean) {
        _backgroundListening.value = enabled
        viewModelScope.launch { engine.setBackgroundListeningPref(enabled) }
    }

    fun saveApiKey(key: String) {
        viewModelScope.launch {
            engine.onApiKeyUpdated(key)
            _apiKeySet.value = true
        }
    }

    fun saveVoice(voice: String) {
        viewModelScope.launch {
            engine.onVoiceUpdated(voice)
            _currentVoice.value = voice
        }
    }

    fun toggleCamera(open: Boolean) {
        engine.setCameraOpen(open)
        _cameraOpen.value = open
    }

    /** fromVoice=true ise (mikrofonla soylendiyse) wake-word mantigi calisir
     *  ve yanit bittiginde mikrofon otomatik tekrar acilir (sesli sohbet modu). */
    fun handleUserUtterance(text: String, fromVoice: Boolean) {
        voiceMode = fromVoice
        viewModelScope.launch {
            if (fromVoice) {
                engine.handleHeardSpeech(text, requireWakeWord = false)
            } else {
                engine.handleUtterance(text)
            }
        }
    }

    /** GeminiAudioRecorder'dan gelen ham ses kaydini yaziya cevirip isler
     *  (cihazin kendi ses tanimasi yerine). wav=null ise (sessizlik/cok kisa) hata gosterir. */
    fun handleRecordedAudio(wav: ByteArray?) {
        voiceMode = true
        if (wav == null) {
            setError("Bir şey duyamadım, tekrar dener misin?")
            return
        }
        viewModelScope.launch {
            _state.value = JarvisState.THINKING
            val text = engine.transcribeAudio(wav)
            if (text.isNullOrBlank()) {
                setError("Sesi anlayamadım, tekrar dener misin?")
                return@launch
            }
            engine.handleHeardSpeech(text, requireWakeWord = false)
        }
    }

    /** Kullanici konusma dongusunu manuel olarak durdurmak icin (mic'e tekrar dokunma). */
    fun stopVoiceMode() {
        voiceMode = false
    }

    fun setListening() { _state.value = JarvisState.LISTENING }
    fun setError(msg: String) {
        _state.value = JarvisState.ERROR
        _messages.value = _messages.value + ChatMessage("jarvis", msg)
    }
    fun setIdle() { _state.value = JarvisState.IDLE }

    override fun onCleared() {
        super.onCleared()
        // Motor (JarvisEngineHolder) surekli yasiyor; ViewModel yok olurken
        // listener referansini birakip sizintiyi onle.
        if (engine.listener != null) engine.listener = null
    }
}
