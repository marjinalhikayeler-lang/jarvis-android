package com.alp.jarvis

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.alp.jarvis.actions.BrowserAction
import com.alp.jarvis.actions.CalendarAction
import com.alp.jarvis.actions.OpenApp
import com.alp.jarvis.actions.SysInfo
import com.alp.jarvis.actions.Weather
import com.alp.jarvis.camera.CameraFrameHolder
import com.alp.jarvis.core.GeminiClient
import com.alp.jarvis.core.GeminiTts
import com.alp.jarvis.core.MemoryManager
import com.alp.jarvis.core.SettingsStore
import com.alp.jarvis.core.SystemPrompt
import com.alp.jarvis.voice.AudioPlayer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class JarvisState { IDLE, LISTENING, THINKING, SPEAKING, ERROR }

data class ChatMessage(val role: String, val text: String) // role: "user" | "jarvis"

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val settings = SettingsStore(app)
    private val memory = MemoryManager(app)

    private val _state = MutableStateFlow(JarvisState.IDLE)
    val state: StateFlow<JarvisState> = _state

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages

    private val _apiKeySet = MutableStateFlow(false)
    val apiKeySet: StateFlow<Boolean> = _apiKeySet

    private val _cameraOpen = MutableStateFlow(false)
    val cameraOpen: StateFlow<Boolean> = _cameraOpen

    private var geminiClient: GeminiClient? = null
    private var apiKey: String? = null
    private val history = JSONArray() // Gemini "contents" formatinda konusma gecmisi

    /** MainActivity, ses cikisi icin bunu constructor sonrasi atar. */
    var audioPlayer: AudioPlayer? = null

    /** Gemini TTS basarisiz olursa devreye giren Android TTS fallback'i. */
    var androidTtsFallback: ((String) -> Unit)? = null

    init {
        viewModelScope.launch {
            val key = settings.getApiKey()
            if (!key.isNullOrBlank()) {
                apiKey = key
                geminiClient = GeminiClient(key)
                _apiKeySet.value = true
            }
        }
    }

    fun saveApiKey(key: String) {
        viewModelScope.launch {
            settings.setApiKey(key)
            apiKey = key
            geminiClient = GeminiClient(key)
            _apiKeySet.value = true
        }
    }

    fun toggleCamera(open: Boolean) {
        _cameraOpen.value = open
        if (!open) CameraFrameHolder.clear()
    }

    fun handleUserUtterance(text: String) {
        if (text.isBlank()) return
        _messages.value = _messages.value + ChatMessage("user", text)
        _state.value = JarvisState.THINKING

        val userParts = JSONArray().put(JSONObject().put("text", text))

        // Kamera aciksa, en son cekilen kareyi de mesaja ekle — JARVIS'in
        // gercekten "gormesini" saglayan kisim burasi.
        if (_cameraOpen.value) {
            CameraFrameHolder.latestJpeg?.let { jpeg ->
                val b64 = android.util.Base64.encodeToString(jpeg, android.util.Base64.NO_WRAP)
                userParts.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject().put("mime_type", "image/jpeg").put("data", b64)
                    )
                )
            }
        }

        history.put(JSONObject().put("role", "user").put("parts", userParts))

        viewModelScope.launch {
            runTurn(depth = 0)
        }
    }

    private suspend fun runTurn(depth: Int) {
        val client = geminiClient
        if (client == null) {
            _state.value = JarvisState.ERROR
            val msg = "Önce Gemini API anahtarını girmelisin."
            _messages.value = _messages.value + ChatMessage("jarvis", msg)
            speak(msg)
            return
        }
        if (depth > 4) { // sonsuz arac cagrisi dongusunu onle
            _state.value = JarvisState.IDLE
            return
        }

        val now = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).format(Date())
        val memoryBlock = memory.formatForPrompt()
        val prompt = SystemPrompt.build(now, memoryBlock)

        val result = client.send(prompt, history)

        if (result.functionCall != null) {
            val (name, args) = result.functionCall

            // Modelin fonksiyon cagrisini AYNEN (id/thoughtSignature dahil)
            // gecmise ekliyoruz — Gemini 3.x bir sonraki adimda bunu bekliyor.
            history.put(JSONObject().put("role", "model").put("parts", result.rawModelParts))

            val actionResult = executeAction(name, args)

            val responsePart = JSONObject().put("name", name)
                .put("response", JSONObject().put("result", actionResult))
            if (result.functionCallId != null) responsePart.put("id", result.functionCallId)

            history.put(
                JSONObject().put("role", "user").put(
                    "parts", JSONArray().put(JSONObject().put("functionResponse", responsePart))
                )
            )

            runTurn(depth + 1)
            return
        }

        val text = result.text ?: "Bir şey söyleyemedim, tekrar dener misin?"
        history.put(
            JSONObject().put("role", "model").put(
                "parts", JSONArray().put(JSONObject().put("text", text))
            )
        )

        _messages.value = _messages.value + ChatMessage("jarvis", text)
        _state.value = JarvisState.SPEAKING
        speak(text)
    }

    /** Once Gemini'nin Charon sesiyle konusturmayi dener, olmazsa Android TTS'e duser. */
    private suspend fun speak(text: String) {
        val key = apiKey
        val player = audioPlayer
        if (key != null && player != null) {
            val wav = GeminiTts.synthesize(key, text, "Charon")
            if (wav != null) {
                player.playWav(wav) { setIdle() }
                return
            }
        }
        androidTtsFallback?.invoke(text) ?: setIdle()
    }

    private suspend fun executeAction(name: String, args: JSONObject): String {
        val app = getApplication<Application>()
        return try {
            when (name) {
                "open_app" -> OpenApp.open(app, args.optString("app_name"))
                "sys_info" -> when (args.optString("kind")) {
                    "battery" -> SysInfo.battery(app)
                    "date" -> SysInfo.date()
                    else -> SysInfo.time()
                }
                "get_weather" -> Weather.summary(args.optString("location"))
                "get_calendar_events" -> CalendarAction.getEvents(app, args.optString("query"))
                "add_calendar_event" -> CalendarAction.addEvent(
                    app, args.optString("title"), args.optString("start_iso"),
                    args.optString("end_iso").ifBlank { null }
                )
                "open_browser" -> BrowserAction.openBrowser(app, args.optString("mode"), args.optString("query"))
                "open_youtube" -> BrowserAction.openYoutube(app, args.optString("query"))
                "save_memory" -> memory.save(args.optString("category"), args.optString("key"), args.optString("value"))
                "delete_memory" -> memory.delete(args.optString("match_text"))
                "open_camera" -> { toggleCamera(true); "Kamera açıldı, seni görüyorum." }
                "close_camera" -> { toggleCamera(false); "Kamera kapatıldı." }
                else -> "Bilinmeyen araç: $name"
            }
        } catch (e: Exception) {
            "Aracı çalıştırırken hata oluştu: ${e.message}"
        }
    }

    fun setIdle() { _state.value = JarvisState.IDLE }
    fun setListening() { _state.value = JarvisState.LISTENING }
    fun setError(msg: String) {
        _state.value = JarvisState.ERROR
        _messages.value = _messages.value + ChatMessage("jarvis", msg)
    }
}
