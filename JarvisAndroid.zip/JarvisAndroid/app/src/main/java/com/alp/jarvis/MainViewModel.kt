package com.alp.jarvis

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.alp.jarvis.actions.BrowserAction
import com.alp.jarvis.actions.CalendarAction
import com.alp.jarvis.actions.OpenApp
import com.alp.jarvis.actions.SysInfo
import com.alp.jarvis.actions.Weather
import com.alp.jarvis.core.GeminiClient
import com.alp.jarvis.core.MemoryManager
import com.alp.jarvis.core.SettingsStore
import com.alp.jarvis.core.SystemPrompt
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class JarvisState { IDLE, LISTENING, THINKING, SPEAKING, ERROR }

data class ChatMessage(val role: String, val text: String) // role: "user" | "jarvis"

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val settings = SettingsStore(app)
    private val memory = MemoryManager(app)

    private val _state = MutableStateFlow(JarvisState.IDLE)
    val state: StateFlow<JarvisState> = _state

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages

    private val _apiKeySet = MutableStateFlow(false)
    val apiKeySet: StateFlow<Boolean> = _apiKeySet

    private var geminiClient: GeminiClient? = null
    private val history = JSONArray() // Gemini "contents" formatinda konusma gecmisi

    init {
        viewModelScope.launch {
            val key = settings.getApiKey()
            if (!key.isNullOrBlank()) {
                geminiClient = GeminiClient(key)
                _apiKeySet.value = true
            }
        }
    }

    fun saveApiKey(key: String) {
        viewModelScope.launch {
            settings.setApiKey(key)
            geminiClient = GeminiClient(key)
            _apiKeySet.value = true
        }
    }

    fun handleUserUtterance(text: String, onSpeak: (String) -> Unit) {
        if (text.isBlank()) return
        _messages.value = _messages.value + ChatMessage("user", text)
        _state.value = JarvisState.THINKING

        history.put(
            JSONObject().put("role", "user").put(
                "parts", JSONArray().put(JSONObject().put("text", text))
            )
        )

        viewModelScope.launch {
            runTurn(onSpeak)
        }
    }

    private suspend fun runTurn(onSpeak: (String) -> Unit, depth: Int = 0) {
        val client = geminiClient
        if (client == null) {
            _state.value = JarvisState.ERROR
            val msg = "Önce Gemini API anahtarını girmelisin."
            _messages.value = _messages.value + ChatMessage("jarvis", msg)
            onSpeak(msg)
            return
        }
        if (depth > 4) { // sonsuz arac cagrisi dongusunu onle
            _state.value = JarvisState.IDLE
            return
        }

        val now = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).format(Date())
        val memoryBlock = memory.formatForPrompt()
        val prompt = SystemPrompt.build(now, memoryBlock)

        val result = client.send(prompt, history)

        if (result.functionCall != null) {
            val (name, args) = result.functionCall
            // modelin fonksiyon cagrisini gecmise ekle
            history.put(
                JSONObject().put("role", "model").put(
                    "parts", JSONArray().put(
                        JSONObject().put("functionCall", JSONObject().put("name", name).put("args", args))
                    )
                )
            )

            val actionResult = executeAction(name, args)

            history.put(
                JSONObject().put("role", "user").put(
                    "parts", JSONArray().put(
                        JSONObject().put(
                            "functionResponse",
                            JSONObject().put("name", name).put(
                                "response", JSONObject().put("result", actionResult)
                            )
                        )
                    )
                )
            )

            // Aracin sonucunu modele geri gonder, nihai cevabi al
            runTurn(onSpeak, depth + 1)
            return
        }

        val text = result.text ?: "Bir şey söyleyemedim, tekrar dener misin?"
        history.put(
            JSONObject().put("role", "model").put(
                "parts", JSONArray().put(JSONObject().put("text", text))
            )
        )

        _messages.value = _messages.value + ChatMessage("jarvis", text)
        _state.value = JarvisState.SPEAKING
        onSpeak(text)
    }

    private suspend fun executeAction(name: String, args: JSONObject): String {
        val app = getApplication<Application>()
        return try {
            when (name) {
                "open_app" -> OpenApp.open(app, args.optString("app_name"))
                "sys_info" -> when (args.optString("kind")) {
                    "battery" -> SysInfo.battery(app)
                    "date" -> SysInfo.date()
                    else -> SysInfo.time()
                }
                "get_weather" -> Weather.summary(args.optString("location"))
                "get_calendar_events" -> CalendarAction.getEvents(app, args.optString("query"))
                "add_calendar_event" -> CalendarAction.addEvent(
                    app, args.optString("title"), args.optString("start_iso"),
                    args.optString("end_iso").ifBlank { null }
                )
                "open_browser" -> BrowserAction.openBrowser(app, args.optString("mode"), args.optString("query"))
                "open_youtube" -> BrowserAction.openYoutube(app, args.optString("query"))
                "save_memory" -> memory.save(args.optString("category"), args.optString("key"), args.optString("value"))
                "delete_memory" -> memory.delete(args.optString("match_text"))
                else -> "Bilinmeyen araç: $name"
            }
        } catch (e: Exception) {
            "Aracı çalıştırırken hata oluştu: ${e.message}"
        }
    }

    fun setIdle() { _state.value = JarvisState.IDLE }
    fun setListening() { _state.value = JarvisState.LISTENING }
    fun setError(msg: String) {
        _state.value = JarvisState.ERROR
        _messages.value = _messages.value + ChatMessage("jarvis", msg)
    }
}
