package com.alp.jarvis.actions

import android.content.Context
import android.provider.ContactsContract

/**
 * Yeni ozellik: rehberden isimle telefon numarasi bulma ("annem",
 * "Ahmet" gibi). WhatsApp mesaji ve telefon aramasi bunu kullanir.
 */
object ContactsAction {

    /** Isme gore (kismi/buyuk-kucuk harf duyarsiz) en iyi eslesen numarayi bulur. */
    fun findPhoneNumber(context: Context, name: String): String? {
        val resolver = context.contentResolver
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%${name.trim()}%")

        resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection, selection, selectionArgs, null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                return cursor.getString(numberIdx)?.replace(" ", "")?.replace("-", "")
            }
        }
        return null
    }
}
