package com.alp.jarvis.actions

import android.content.Context
import android.provider.ContactsContract
import java.util.Locale

/**
 * Yeni ozellik: rehberden isimle telefon numarasi bulma ("annem",
 * "Ahmet" gibi). WhatsApp mesaji ve telefon aramasi bunu kullanir.
 */
object ContactsAction {

    /**
     * Once tum "%isim%" eslesen kisileri cekip kod tarafinda siraliyoruz:
     * 1) tam eslesme (buyuk/kucuk harf duyarsiz)
     * 2) isimle baslayan
     * 3) icinde gecen (en son care)
     * Bu sekilde "annem" aramasi "anneanne" gibi alakasiz ama kismen
     * benzer isimlerle karismiyor.
     */
    fun findPhoneNumber(context: Context, name: String): String? {
        val query = name.trim()
        if (query.isBlank()) return null

        val resolver = context.contentResolver
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$query%")

        data class Candidate(val displayName: String, val number: String)
        val candidates = mutableListOf<Candidate>()

        resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection, selection, selectionArgs, null
        )?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (cursor.moveToNext()) {
                val dn = cursor.getString(nameIdx) ?: continue
                val num = cursor.getString(numberIdx)?.replace(" ", "")?.replace("-", "") ?: continue
                candidates.add(Candidate(dn, num))
            }
        }

        if (candidates.isEmpty()) return null

        val queryLower = query.lowercase(Locale.getDefault())
        val exact = candidates.firstOrNull { it.displayName.lowercase(Locale.getDefault()) == queryLower }
        if (exact != null) return exact.number

        val startsWith = candidates.firstOrNull { it.displayName.lowercase(Locale.getDefault()).startsWith(queryLower) }
        if (startsWith != null) return startsWith.number

        return candidates.first().number
    }
}
