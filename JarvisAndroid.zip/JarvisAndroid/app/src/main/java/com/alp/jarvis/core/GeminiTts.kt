package com.alp.jarvis.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

/**
 * Windows suerumunde Gemini Live'in "Charon" sesi kullaniliyordu
 * (VOICES = [Charon, Puck, Aoede, Kore, Fenrir, Leda, Orus, Zephyr]).
 * Android'de Live API yerine Gemini'nin ayri metinden-sese (TTS)
 * generateContent uc noktasini ayni ses ismiyle cagiriyoruz, boylece
 * ses birebir aynisi oluyor. Basarisiz olursa (agsiz, kota vb.)
 * cagiran taraf Android'in yerlesik TextToSpeech'ine dusebilir.
 */
object GeminiTts {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private const val MODEL = "gemini-3.1-flash-tts-preview"
    private val URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    /** Basarili olursa calinmaya hazir bir WAV byte dizisi doner, aksi halde null. */
    suspend fun synthesize(apiKey: String, text: String, voiceName: String = "Charon"): ByteArray? =
        withContext(Dispatchers.IO) {
            try {
                val body = JSONObject()
                body.put("contents", org.json.JSONArray().put(
                    JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", text)))
                ))
                body.put(
                    "generationConfig",
                    JSONObject()
                        .put("responseModalities", org.json.JSONArray().put("AUDIO"))
                        .put(
                            "speechConfig",
                            JSONObject().put(
                                "voiceConfig",
                                JSONObject().put(
                                    "prebuiltVoiceConfig",
                                    JSONObject().put("voiceName", voiceName)
                                )
                            )
                        )
                )

                val request = Request.Builder()
                    .url("$URL?key=$apiKey")
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                client.newCall(request).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext null
                    val bodyStr = resp.body?.string() ?: return@withContext null
                    val json = JSONObject(bodyStr)
                    val candidates = json.optJSONArray("candidates") ?: return@withContext null
                    if (candidates.length() == 0) return@withContext null
                    val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                        ?: return@withContext null

                    for (i in 0 until parts.length()) {
                        val inline = parts.getJSONObject(i).optJSONObject("inlineData") ?: continue
                        val b64 = inline.optString("data")
                        val mime = inline.optString("mimeType", "audio/L16;rate=24000")
                        if (b64.isNotBlank()) {
                            val pcm = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                            val rate = Regex("rate=(\\d+)").find(mime)?.groupValues?.get(1)?.toIntOrNull() ?: 24000
                            return@withContext pcmToWav(pcm, rate)
                        }
                    }
                    null
                }
            } catch (e: Exception) {
                null
            }
        }

    /** Gemini TTS ham 16-bit mono PCM doner; Android MediaPlayer icin WAV zarfina sariyoruz. */
    private fun pcmToWav(pcm: ByteArray, sampleRate: Int, channels: Int = 1, bitsPerSample: Int = 16): ByteArray {
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val blockAlign = channels * bitsPerSample / 8
        val dataSize = pcm.size
        val out = ByteArrayOutputStream(44 + dataSize)

        fun writeIntLE(v: Int) {
            out.write(v and 0xff); out.write((v shr 8) and 0xff)
            out.write((v shr 16) and 0xff); out.write((v shr 24) and 0xff)
        }
        fun writeShortLE(v: Int) {
            out.write(v and 0xff); out.write((v shr 8) and 0xff)
        }

        out.write("RIFF".toByteArray())
        writeIntLE(36 + dataSize)
        out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray())
        writeIntLE(16) // PCM fmt chunk size
        writeShortLE(1) // audio format = PCM
        writeShortLE(channels)
        writeIntLE(sampleRate)
        writeIntLE(byteRate)
        writeShortLE(blockAlign)
        writeShortLE(bitsPerSample)
        out.write("data".toByteArray())
        writeIntLE(dataSize)
        out.write(pcm)

        return out.toByteArray()
    }
}
