package com.alp.jarvis.voice

import android.content.Context
import android.media.MediaPlayer
import java.io.File
import java.io.FileOutputStream

/**
 * Gemini TTS'ten gelen WAV byte dizisini calar. Android'in MediaPlayer'i
 * dogrudan byte dizisi kabul etmedigi icin gecici bir dosyaya yazip
 * ondan calıyoruz (cache dizini, uygulama kapaninca otomatik temizlenir).
 */
class AudioPlayer(private val context: Context) {

    private var player: MediaPlayer? = null

    fun playWav(bytes: ByteArray, onDone: () -> Unit) {
        stop()
        try {
            val file = File(context.cacheDir, "jarvis_tts_${System.currentTimeMillis()}.wav")
            FileOutputStream(file).use { it.write(bytes) }

            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnCompletionListener {
                    it.release()
                    file.delete()
                    onDone()
                }
                setOnErrorListener { mp, _, _ ->
                    mp.release()
                    file.delete()
                    onDone()
                    true
                }
                prepare()
                start()
            }
        } catch (e: Exception) {
            onDone()
        }
    }

    fun stop() {
        try {
            player?.stop()
            player?.release()
        } catch (_: Exception) {}
        player = null
    }
}
