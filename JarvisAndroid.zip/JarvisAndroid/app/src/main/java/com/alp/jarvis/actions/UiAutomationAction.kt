package com.alp.jarvis.actions

import android.content.Context
import com.alp.jarvis.accessibility.AccessibilityUtils
import com.alp.jarvis.accessibility.JarvisAccessibilityService

/**
 * "Herhangi bir uygulamada bir seye dokun/yaz" icin genel amacli
 * otomasyon. Su an ekranda ne aciksa onun uzerinde calisir — genelde
 * once open_app ile uygulama acilir, sonra bu cagrilir. Erisilebilirlik
 * izni gerektirir; her uygulamanin arayuzu farkli oldugu icin %100
 * garanti calismaz (en iyi caba).
 */
object UiAutomationAction {

    private fun requireService(): JarvisAccessibilityService? = JarvisAccessibilityService.instance

    fun tap(context: Context, text: String): String {
        if (!AccessibilityUtils.isServiceEnabled(context)) return needsPermissionMessage()
        val svc = requireService() ?: return "Otomasyon servisi şu an aktif değil, telefonu bir kez yeniden başlatman gerekebilir."
        return if (svc.tapText(text)) "\"$text\" yazan yere dokundum."
        else "Ekranda \"$text\" ile eşleşen bir şey bulamadım."
    }

    fun type(context: Context, text: String): String {
        if (!AccessibilityUtils.isServiceEnabled(context)) return needsPermissionMessage()
        val svc = requireService() ?: return "Otomasyon servisi şu an aktif değil, telefonu bir kez yeniden başlatman gerekebilir."
        return if (svc.typeText(text)) "\"$text\" yazıldı."
        else "Şu an odakta yazı yazılabilecek bir alan bulamadım. Önce dokunup bir metin kutusu seçmen gerekebilir."
    }

    fun scroll(context: Context, forward: Boolean): String {
        if (!AccessibilityUtils.isServiceEnabled(context)) return needsPermissionMessage()
        val svc = requireService() ?: return "Otomasyon servisi şu an aktif değil."
        return if (svc.scroll(forward)) "Kaydırdım." else "Kaydırılabilecek bir alan bulamadım."
    }

    fun back(context: Context): String {
        if (!AccessibilityUtils.isServiceEnabled(context)) return needsPermissionMessage()
        val svc = requireService() ?: return "Otomasyon servisi şu an aktif değil."
        return if (svc.goBack()) "Geri gidildi." else "Geri gidilemedi."
    }

    fun home(context: Context): String {
        if (!AccessibilityUtils.isServiceEnabled(context)) return needsPermissionMessage()
        val svc = requireService() ?: return "Otomasyon servisi şu an aktif değil."
        return if (svc.goHome()) "Ana ekrana dönüldü." else "Ana ekrana dönülemedi."
    }

    private fun needsPermissionMessage() =
        "Bunu yapabilmem için Ayarlar'dan JARVIS'e Otomasyon (Erişilebilirlik) izni vermen gerekiyor, tek seferlik."
}
