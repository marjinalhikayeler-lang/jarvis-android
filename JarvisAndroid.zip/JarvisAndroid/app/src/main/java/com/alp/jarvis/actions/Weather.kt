package com.alp.jarvis.actions

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Windows suerumundeki actions/weather.py karsiligi.
 * Open-Meteo kullanir (ucretsiz, API anahtari gerektirmez).
 */
object Weather {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun summary(location: String): String = withContext(Dispatchers.IO) {
        try {
            val encoded = URLEncoder.encode(location, "UTF-8")
            val geoReq = Request.Builder()
                .url("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=tr")
                .build()

            val geoBody = client.newCall(geoReq).execute().use { it.body?.string() } ?: return@withContext "Konum bulunamadı."
            val geoJson = JSONObject(geoBody)
            val results = geoJson.optJSONArray("results") ?: return@withContext "\"$location\" için konum bulunamadı."
            if (results.length() == 0) return@withContext "\"$location\" için konum bulunamadı."

            val place = results.getJSONObject(0)
            val lat = place.getDouble("latitude")
            val lon = place.getDouble("longitude")
            val placeName = place.optString("name", location)

            val wReq = Request.Builder()
                .url("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m")
                .build()

            val wBody = client.newCall(wReq).execute().use { it.body?.string() } ?: return@withContext "Hava durumu alınamadı."
            val wJson = JSONObject(wBody)
            val current = wJson.getJSONObject("current")
            val temp = current.getDouble("temperature_2m")
            val humidity = current.getInt("relative_humidity_2m")
            val wind = current.getDouble("wind_speed_10m")
            val code = current.getInt("weather_code")

            "$placeName için hava durumu: ${temp}°C, nem %$humidity, rüzgar ${wind} km/s. ${describeCode(code)}"
        } catch (e: Exception) {
            "Hava durumu alınırken bir sorun oluştu: ${e.message}"
        }
    }

    private fun describeCode(code: Int): String = when (code) {
        0 -> "Açık hava."
        1, 2, 3 -> "Parçalı bulutlu."
        45, 48 -> "Sisli."
        51, 53, 55 -> "Çisenti var."
        61, 63, 65 -> "Yağmurlu."
        71, 73, 75 -> "Karlı."
        95, 96, 99 -> "Fırtınalı."
        else -> ""
    }
}
