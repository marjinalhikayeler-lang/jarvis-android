package com.alp.jarvis.core

/**
 * CallScreeningService, gelen her arama icin bunu anlik kontrol eder.
 * Disk okumasi zaman kritik oldugu icin bellekte tutuluyor; JarvisEngine
 * baslangicta SettingsStore'dan yukluyor, degistiginde hem burasi hem
 * SettingsStore guncelleniyor.
 */
object CallPolicy {
    @Volatile
    var autoReject: Boolean = false
}
