package com.alp.jarvis.accessibility

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Kullanicinin Ayarlar > Erisilebilirlik'ten elle actigi (Android'in
 * guvenlik kurali, kod tarafindan acilamiyor) bir servis. Sadece
 * AutomationState'te "bekleyen bir aksiyon" varken bir sey yapar; aksi
 * halde tamamen pasif durur, hicbir veri toplamaz/gondermez.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!AutomationState.isActive()) return
        val root = rootInActiveWindow ?: return

        val handled = when (AutomationState.pending) {
            PendingAction.WHATSAPP_SEND -> handleWhatsAppSend(root)
            PendingAction.WHATSAPP_CALL -> handleWhatsAppCall(root)
            PendingAction.SPOTIFY_PLAY_FIRST -> handleSpotifyPlayFirst(root)
            PendingAction.NONE -> true
        }
        if (handled) AutomationState.clear()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    // ---------------- Genel amacli otomasyon (herhangi bir uygulama) ----------------
    // Bunlar "su an ekranda ne varsa onun uzerinde" calisir; open_app ile bir
    // uygulama acildiktan SONRA cagrilmasi beklenir.

    /** Ekranda gorunen, verilen metni tam/kismen iceren tiklanabilir bir ogeye dokunur. */
    fun tapText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val exact = findByTextOrDescription(root, text, exact = true, depth = 0)
        if (exact != null && clickUpward(exact)) return true
        val partial = findByTextOrDescription(root, text, exact = false, depth = 0)
        return partial != null && clickUpward(partial)
    }

    /** O an odakta (kursor yanip sonen) bir yazi alanina metin girer. */
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = findFocusedEditable(root, 0) ?: return false
        val args = android.os.Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Ekrandaki ilk kaydirilabilir alani asagi/yukari kaydirir. */
    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findScrollable(root, 0) ?: return false
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return scrollable.performAction(action)
    }

    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    private fun findByTextOrDescription(node: AccessibilityNodeInfo, query: String, exact: Boolean, depth: Int): AccessibilityNodeInfo? {
        if (depth > 80) return null
        val txt = node.text?.toString()
        val cd = node.contentDescription?.toString()
        val match: (String?) -> Boolean = { s ->
            s != null && (if (exact) s.equals(query, ignoreCase = true) else s.contains(query, ignoreCase = true))
        }
        if (match(txt) || match(cd)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findByTextOrDescription(child, query, exact, depth + 1)?.let { return it }
        }
        return null
    }

    private fun findFocusedEditable(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 80) return null
        if (node.isFocused && node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findFocusedEditable(child, depth + 1)?.let { return it }
        }
        return null
    }

    private fun findScrollable(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 80) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findScrollable(child, depth + 1)?.let { return it }
        }
        return null
    }

    // ---------------- WhatsApp ----------------

    private fun handleWhatsAppSend(root: AccessibilityNodeInfo): Boolean {
        clickByTexts(root, CONTINUE_TEXTS) // "Sohbete devam et" onay ekrani cikarsa gec
        return clickByViewId(root, "com.whatsapp:id/send") ||
            clickByDescription(root, listOf("Send", "Gönder"))
    }

    private fun handleWhatsAppCall(root: AccessibilityNodeInfo): Boolean {
        clickByTexts(root, CONTINUE_TEXTS)
        return clickByViewId(root, "com.whatsapp:id/menuitem_voice_call") ||
            clickByDescription(root, listOf("Voice call", "Sesli arama", "Call"))
    }

    // ---------------- Spotify ----------------

    private fun handleSpotifyPlayFirst(root: AccessibilityNodeInfo): Boolean {
        // Spotify sarki satirlari genelde "Play <sarki adi> by <sanatci>" seklinde
        // erisilebilirlik etiketi tasir — en guvenilir yontem bu.
        val playNode = findFirstByDescriptionPrefix(root, "Play ", 0)
        if (playNode != null && clickUpward(playNode)) return true

        // Bulunamazsa: sonuc listesindeki ilk tiklanabilir satiri dene (en iyi caba,
        // Spotify arayuzu degisirse bu kisim daha az guvenilir olabilir).
        val firstRow = findFirstListRow(root, 0)
        return firstRow != null && clickUpward(firstRow)
    }

    // ---------------- yardimcilar ----------------

    private fun clickByTexts(root: AccessibilityNodeInfo, texts: List<String>): Boolean {
        for (t in texts) {
            val nodes = root.findAccessibilityNodeInfosByText(t)
            for (n in nodes) if (clickUpward(n)) return true
        }
        return false
    }

    private fun clickByViewId(root: AccessibilityNodeInfo, id: String): Boolean {
        val nodes = root.findAccessibilityNodeInfosByViewId(id)
        for (n in nodes) if (clickUpward(n)) return true
        return false
    }

    private fun clickByDescription(root: AccessibilityNodeInfo, descs: List<String>): Boolean {
        val node = findByDescription(root, descs, 0) ?: return false
        return clickUpward(node)
    }

    private fun findByDescription(node: AccessibilityNodeInfo, descs: List<String>, depth: Int): AccessibilityNodeInfo? {
        if (depth > 50) return null
        val cd = node.contentDescription?.toString()
        if (cd != null && descs.any { cd.contains(it, ignoreCase = true) }) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findByDescription(child, descs, depth + 1)?.let { return it }
        }
        return null
    }

    private fun findFirstByDescriptionPrefix(node: AccessibilityNodeInfo, prefix: String, depth: Int): AccessibilityNodeInfo? {
        if (depth > 60) return null
        val cd = node.contentDescription?.toString()
        if (cd != null && cd.startsWith(prefix, ignoreCase = true)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findFirstByDescriptionPrefix(child, prefix, depth + 1)?.let { return it }
        }
        return null
    }

    private fun findFirstListRow(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 60) return null
        val cls = node.className?.toString() ?: ""
        if (cls.contains("RecyclerView") || cls.contains("ListView")) {
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                if (child.isClickable) return child
                findClickableDescendant(child, 0)?.let { return it }
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findFirstListRow(child, depth + 1)?.let { return it }
        }
        return null
    }

    private fun findClickableDescendant(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 10) return null
        if (node.isClickable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findClickableDescendant(child, depth + 1)?.let { return it }
        }
        return null
    }

    private fun clickUpward(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var hops = 0
        while (current != null && hops < 8) {
            if (current.isClickable) return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            current = current.parent
            hops++
        }
        return false
    }

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
            private set

        private val CONTINUE_TEXTS = listOf(
            "Continue to chat", "CONTINUE TO CHAT", "Sohbete devam et", "SOHBETE DEVAM ET", "Devam"
        )
    }
}
