package com.alp.jarvis.accessibility

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * Kullanicinin Ayarlar > Erisilebilirlik'ten elle actigi (Android'in
 * guvenlik kurali, kod tarafindan acilamiyor) bir servis. Sadece
 * AutomationState'te "bekleyen bir aksiyon" varken bir sey yapar; aksi
 * halde tamamen pasif durur, hicbir veri toplamaz/gondermez.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!AutomationState.isActive()) return
        val root = rootInActiveWindow ?: return

        val handled = when (AutomationState.pending) {
            PendingAction.WHATSAPP_SEND -> handleWhatsAppSend(root)
            PendingAction.WHATSAPP_CALL -> handleWhatsAppCall(root)
            PendingAction.SPOTIFY_PLAY_FIRST -> handleSpotifyPlayFirst(root)
            PendingAction.NONE -> true
        }
        if (handled) AutomationState.clear()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    // ---------------- Genel amacli otomasyon (herhangi bir uygulama) ----------------
    // Bunlar "su an ekranda ne varsa onun uzerinde" calisir; open_app ile bir
    // uygulama acildiktan SONRA cagrilmasi beklenir.

    /** Ekranda gorunen, verilen metni tam/kismen iceren tiklanabilir bir ogeye dokunur. */
    fun tapText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val exact = findByTextOrDescription(root, text, exact = true, depth = 0)
        if (exact != null && clickUpward(exact)) return true
        val partial = findByTextOrDescription(root, text, exact = false, depth = 0)
        return partial != null && clickUpward(partial)
    }

    /** O an odakta (kursor yanip sonen) bir yazi alanina metin girer. */
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = findFocusedEditable(root, 0) ?: return false
        val args = android.os.Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Ekrandaki ilk kaydirilabilir alani asagi/yukari kaydirir. */
    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findScrollable(root, 0) ?: return false
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return scrollable.performAction(action)
    }

    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    private fun findByTextOrDescription(node: AccessibilityNodeInfo, query: String, exact: Boolean, depth: Int): AccessibilityNodeInfo? {
        if (depth > 80) return null
        val txt = node.text?.toString()
        val cd = node.contentDescription?.toString()
        val match: (String?) -> Boolean = { s ->
            s != null && (if (exact) s.equals(query, ignoreCase = true) else s.contains(query, ignoreCase = true))
        }
        if (match(txt) || match(cd)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findByTextOrDescription(child, query, exact, depth + 1)?.let { return it }
        }
        return null
    }

    private fun findFocusedEditable(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 80) return null
        if (node.isFocused && node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findFocusedEditable(child, depth + 1)?.let { return it }
        }
        return null
    }

    private fun findScrollable(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 80) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findScrollable(child, depth + 1)?.let { return it }
        }
        return null
    }

    // ---------------- WhatsApp ----------------

    private fun handleWhatsAppSend(root: AccessibilityNodeInfo): Boolean {
        clickByTexts(root, CONTINUE_TEXTS) // "Sohbete devam et" onay ekrani cikarsa gec

        if (clickByViewId(root, "com.whatsapp:id/send")) return true
        if (clickByDescription(root, listOf("Send", "Gönder"))) return true

        // Sabit ID/aciklama bulunamadi (WhatsApp surumu farkli olabilir) —
        // gonderdigimiz mesaj metnini yazi kutusunda arayip, o kutunun
        // yanindaki tiklanabilir simgeyi (gonder butonu) bulmayi dene.
        val hint = AutomationState.messageHint
        if (!hint.isNullOrBlank()) {
            val editNode = findEditableContaining(root, hint, 0)
            if (editNode != null) {
                val sibling = findClickableNear(editNode)
                if (sibling != null && clickUpward(sibling)) return true
            }
        }

        // Son care: WhatsApp'ta gonder butonu her zaman ekranin alt kismi ve
        // en sagi — metin/ID eslesmesi olmasa bile bu konumdaki tiklanabilir
        // ogeyi dene.
        val bottomRight = findBottomRightClickable(root)
        if (bottomRight != null && clickUpward(bottomRight)) return true

        return false
    }

    private fun handleWhatsAppCall(root: AccessibilityNodeInfo): Boolean {
        clickByTexts(root, CONTINUE_TEXTS)
        if (clickByViewId(root, "com.whatsapp:id/menuitem_voice_call")) return true
        if (clickByViewId(root, "com.whatsapp:id/menuitem_call")) return true

        // Aciklama eslesmesinde "video"/"görüntü" geçen HİÇBİR dugmeye
        // dokunmuyoruz — WhatsApp'ta sesli/goruntulu arama simgeleri yan
        // yana oldugu icin, "arama" gibi genel bir kelime yanlislikla
        // goruntulu aramayla eslesebiliyordu (bu, daha once yasanan hataydi).
        val node = findVoiceCallOnly(root, 0)
        return node != null && clickUpward(node)
    }

    private fun findVoiceCallOnly(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 60) return null
        val cd = node.contentDescription?.toString()?.lowercase(Locale.getDefault())
        if (cd != null) {
            val isVideo = cd.contains("video") || cd.contains("görüntü") || cd.contains("goruntu")
            val isCall = cd.contains("call") || cd.contains("ara")
            if (isCall && !isVideo) return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findVoiceCallOnly(child, depth + 1)?.let { return it }
        }
        return null
    }

    // ---------------- Spotify ----------------

    private fun handleSpotifyPlayFirst(root: AccessibilityNodeInfo): Boolean {
        // Spotify sarki satirlari genelde "Play <sarki adi> by <sanatci>" seklinde
        // erisilebilirlik etiketi tasir — en guvenilir yontem bu.
        val playNode = findFirstByDescriptionPrefix(root, "Play ", 0)
        if (playNode != null && clickUpward(playNode)) return true

        // Bulunamazsa: kaydirilabilir alandaki tiklanabilir satirlari topla,
        // ekranda en ustte olandan basla dene (arama kutusu/filtre cipsleri
        // genelde bunlarin uzerinde kaliyor).
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        collectClickableRows(root, candidates, 0)
        if (candidates.isNotEmpty()) {
            val bounds = android.graphics.Rect()
            candidates.sortBy { n -> n.getBoundsInScreen(bounds); bounds.top }
            for (n in candidates) {
                if (clickUpward(n)) return true
            }
        }
        return false
    }

    // ---------------- yardimcilar ----------------

    /** Verilen metnin bir kismini iceren (yazilmis mesaj gibi) bir yazi alanini bulur. */
    private fun findEditableContaining(node: AccessibilityNodeInfo, text: String, depth: Int): AccessibilityNodeInfo? {
        if (depth > 80) return null
        val needle = text.take(20)
        val txt = node.text?.toString()
        if (node.isEditable && !txt.isNullOrBlank() && needle.isNotBlank() &&
            (txt.contains(needle, ignoreCase = true) || needle.contains(txt, ignoreCase = true))
        ) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findEditableContaining(child, text, depth + 1)?.let { return it }
        }
        return null
    }

    /** Bir dugumun birkac ust seviyesindeki kapsayicisi icinde, kendisi
     *  disindaki (ve yazi alani olmayan) tiklanabilir bir kardes/torun arar —
     *  genelde "gonder" gibi ikon dugmeler boyle bulunur. */
    private fun findClickableNear(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var ancestor: AccessibilityNodeInfo? = node.parent
        var hops = 0
        while (ancestor != null && hops < 4) {
            findClickableExcludingEditable(ancestor, 0)?.let { return it }
            ancestor = ancestor.parent
            hops++
        }
        return null
    }

    private fun findClickableExcludingEditable(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 10) return null
        val cls = node.className?.toString() ?: ""
        if (node.isClickable && !node.isEditable && !cls.contains("EditText")) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findClickableExcludingEditable(child, depth + 1)?.let { return it }
        }
        return null
    }

    private fun collectClickableRows(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 60) return
        val cls = node.className?.toString() ?: ""
        if (cls.contains("RecyclerView") || cls.contains("ListView")) {
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                val clickableDesc = if (child.isClickable) child else findClickableDescendant(child, 0)
                if (clickableDesc != null) out.add(clickableDesc)
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectClickableRows(child, out, depth + 1)
        }
    }

    /** Ekranin alt %25'lik diliminde, en sagdaki tiklanabilir ogeyi bulur —
     *  WhatsApp'ta gonder butonu her zaman bu konumda. */
    private fun findBottomRightClickable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val screenBounds = android.graphics.Rect()
        root.getBoundsInScreen(screenBounds)
        if (screenBounds.height() <= 0) return null
        val bottomThreshold = screenBounds.top + (screenBounds.height() * 0.75f).toInt()

        val candidates = mutableListOf<AccessibilityNodeInfo>()
        collectAllClickable(root, candidates, 0)

        val bounds = android.graphics.Rect()
        val inBottomArea = candidates.filter { n ->
            n.getBoundsInScreen(bounds)
            bounds.top >= bottomThreshold
        }
        if (inBottomArea.isEmpty()) return null

        return inBottomArea.maxByOrNull { n ->
            n.getBoundsInScreen(bounds)
            bounds.right
        }
    }

    private fun collectAllClickable(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 80) return
        val cls = node.className?.toString() ?: ""
        if (node.isClickable && !cls.contains("EditText")) out.add(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectAllClickable(child, out, depth + 1)
        }
    }

    private fun clickByTexts(root: AccessibilityNodeInfo, texts: List<String>): Boolean {
        for (t in texts) {
            val nodes = root.findAccessibilityNodeInfosByText(t)
            for (n in nodes) if (clickUpward(n)) return true
        }
        return false
    }

    private fun clickByViewId(root: AccessibilityNodeInfo, id: String): Boolean {
        val nodes = root.findAccessibilityNodeInfosByViewId(id)
        for (n in nodes) if (clickUpward(n)) return true
        return false
    }

    private fun clickByDescription(root: AccessibilityNodeInfo, descs: List<String>): Boolean {
        val node = findByDescription(root, descs, 0) ?: return false
        return clickUpward(node)
    }

    private fun findByDescription(node: AccessibilityNodeInfo, descs: List<String>, depth: Int): AccessibilityNodeInfo? {
        if (depth > 50) return null
        val cd = node.contentDescription?.toString()
        if (cd != null && descs.any { cd.contains(it, ignoreCase = true) }) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findByDescription(child, descs, depth + 1)?.let { return it }
        }
        return null
    }

    private fun findFirstByDescriptionPrefix(node: AccessibilityNodeInfo, prefix: String, depth: Int): AccessibilityNodeInfo? {
        if (depth > 60) return null
        val cd = node.contentDescription?.toString()
        if (cd != null && cd.startsWith(prefix, ignoreCase = true)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findFirstByDescriptionPrefix(child, prefix, depth + 1)?.let { return it }
        }
        return null
    }

    private fun findClickableDescendant(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 10) return null
        if (node.isClickable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findClickableDescendant(child, depth + 1)?.let { return it }
        }
        return null
    }

    private fun clickUpward(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var hops = 0
        while (current != null && hops < 8) {
            if (current.isClickable) return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            current = current.parent
            hops++
        }
        return false
    }

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
            private set

        private val CONTINUE_TEXTS = listOf(
            "Continue to chat", "CONTINUE TO CHAT", "Sohbete devam et", "SOHBETE DEVAM ET", "Devam"
        )
    }
}
