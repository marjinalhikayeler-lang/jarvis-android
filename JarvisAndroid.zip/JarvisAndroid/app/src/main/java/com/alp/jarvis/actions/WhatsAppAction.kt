package com.alp.jarvis.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.net.URLEncoder

/**
 * WhatsApp'in resmi "click to chat" linkini kullanir: sohbeti mesaj
 * onceden yazilmis halde acar. WhatsApp, uygulamalarin "gonder"
 * tusuna otomatik basmasina izin vermiyor (spam onlemi) — bu yuzden
 * son dokunusu kullanici yapmali. Bu, Android/WhatsApp'in kendi
 * kisitlamasi, atlanamiyor.
 */
object WhatsAppAction {

    fun sendMessage(context: Context, contactName: String, message: String): String {
        val number = ContactsAction.findPhoneNumber(context, contactName)
            ?: return "\"$contactName\" adında bir kişi rehberde bulunamadı."

        val normalized = normalizeForWhatsApp(number)
        val url = "https://wa.me/$normalized?text=" + URLEncoder.encode(message, "UTF-8")

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)

        return "$contactName için WhatsApp'ı mesaj hazır şekilde açtım, göndermek için dokunman yeterli."
    }

    /** WhatsApp uluslararasi format ister: bosluk/tire yok, basinda + olabilir ama olmasa da olur. */
    private fun normalizeForWhatsApp(rawNumber: String): String {
        var n = rawNumber.replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
        if (n.startsWith("+")) n = n.substring(1)
        if (n.startsWith("0")) n = "90" + n.substring(1) // Turkiye varsayilan kodu
        return n
    }
}
