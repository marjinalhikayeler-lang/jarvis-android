package com.alp.jarvis.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.alp.jarvis.accessibility.AccessibilityUtils
import com.alp.jarvis.accessibility.AutomationState
import com.alp.jarvis.accessibility.PendingAction
import java.net.URLEncoder

/**
 * WhatsApp'in resmi "click to chat" linkini kullanir. Erisilebilirlik
 * izni aciksa (bkz. accessibility/), JarvisAccessibilityService sohbet
 * acildiginda "Gonder"/"Ara" dugmesine kendisi dokunur — degilse
 * kullanicinin son dokunusu yapmasi gerekir.
 */
object WhatsAppAction {

    fun sendMessage(context: Context, contactName: String, message: String): String {
        val number = ContactsAction.findPhoneNumber(context, contactName)
            ?: return "\"$contactName\" adında bir kişi rehberde bulunamadı."

        val normalized = normalizeForWhatsApp(number)
        val url = "https://wa.me/$normalized?text=" + URLEncoder.encode(message, "UTF-8")
        val automationOn = AccessibilityUtils.isServiceEnabled(context)
        if (automationOn) AutomationState.request(PendingAction.WHATSAPP_SEND, hint = message)

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)

        return if (automationOn) "$contactName için WhatsApp mesajı gönderiliyor."
        else "$contactName için WhatsApp'ı mesaj hazır şekilde açtım, göndermek için dokunman yeterli. " +
            "Otomatik göndermesi için Ayarlar'dan Erişilebilirlik iznini bir kez açman gerekiyor."
    }

    fun call(context: Context, contactName: String): String {
        val number = ContactsAction.findPhoneNumber(context, contactName)
            ?: return "\"$contactName\" adında bir kişi rehberde bulunamadı."

        val normalized = normalizeForWhatsApp(number)
        val url = "https://wa.me/$normalized"
        val automationOn = AccessibilityUtils.isServiceEnabled(context)
        if (automationOn) AutomationState.request(PendingAction.WHATSAPP_CALL)

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)

        return if (automationOn) "$contactName WhatsApp'tan aranıyor."
        else "$contactName için WhatsApp sohbetini açtım, arama tuşuna dokunman gerekiyor. " +
            "Otomatik araması için Ayarlar'dan Erişilebilirlik iznini bir kez açman gerekiyor."
    }

    /** WhatsApp uluslararasi format ister: bosluk/tire yok, basinda + olabilir ama olmasa da olur. */
    private fun normalizeForWhatsApp(rawNumber: String): String {
        var n = rawNumber.replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
        if (n.startsWith("+")) n = n.substring(1)
        if (n.startsWith("0")) n = "90" + n.substring(1) // Turkiye varsayilan kodu
        return n
    }
}
