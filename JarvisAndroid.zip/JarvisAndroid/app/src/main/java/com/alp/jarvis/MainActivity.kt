package com.alp.jarvis

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import com.alp.jarvis.ui.JarvisScreen
import com.alp.jarvis.voice.AudioPlayer
import com.alp.jarvis.voice.SpeechInput
import com.alp.jarvis.voice.SpeechOutput

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()
    private var speechInput: SpeechInput? = null
    private var speechOutput: SpeechOutput? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* sonuclar ilgili tetikleyicilerde kontrol edilir */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Gerekli izinleri en basta iste (mikrofon, kamera, takvim)
        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA,
                Manifest.permission.READ_CALENDAR,
                Manifest.permission.WRITE_CALENDAR
            )
        )

        // Android TTS: Gemini TTS basarisiz olursa (agsiz vb.) devreye giren yedek ses
        speechOutput = SpeechOutput(this) { speaking ->
            if (!speaking) viewModel.setIdle()
        }
        viewModel.androidTtsFallback = { text -> speechOutput?.speak(text) }

        // Gemini TTS (Charon sesi) icin oynatici
        viewModel.audioPlayer = AudioPlayer(this)

        speechInput = SpeechInput(
            context = this,
            onResult = { text -> viewModel.handleUserUtterance(text) },
            onError = { err -> viewModel.setError(err) },
            onListeningChange = { listening -> if (listening) viewModel.setListening() }
        )

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val state by viewModel.state.collectAsState()
                val messages by viewModel.messages.collectAsState()
                val apiKeySet by viewModel.apiKeySet.collectAsState()
                val cameraOpen by viewModel.cameraOpen.collectAsState()

                JarvisScreen(
                    state = state,
                    messages = messages,
                    apiKeySet = apiKeySet,
                    cameraOpen = cameraOpen,
                    onMicClick = { onMicClick() },
                    onSendText = { text -> viewModel.handleUserUtterance(text) },
                    onSaveApiKey = { key -> viewModel.saveApiKey(key) },
                    onCameraToggle = { open -> onCameraToggle(open) }
                )
            }
        }
    }

    private fun onMicClick() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        speechInput?.startListening()
    }

    private fun onCameraToggle(open: Boolean) {
        if (open) {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                return
            }
        }
        viewModel.toggleCamera(open)
    }

    override fun onDestroy() {
        super.onDestroy()
        speechInput?.destroy()
        speechOutput?.shutdown()
        viewModel.audioPlayer?.stop()
    }
}
