package com.alp.jarvis

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import com.alp.jarvis.ui.JarvisScreen
import com.alp.jarvis.voice.SpeechInput
import com.alp.jarvis.voice.SpeechOutput

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()
    private var speechInput: SpeechInput? = null
    private var speechOutput: SpeechOutput? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* sonuclar handleMic() icinde kontrol edilir */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Gerekli izinleri en basta iste (mikrofon, takvim)
        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CALENDAR,
                Manifest.permission.WRITE_CALENDAR
            )
        )

        speechOutput = SpeechOutput(this) { speaking ->
            if (!speaking) viewModel.setIdle()
        }

        speechInput = SpeechInput(
            context = this,
            onResult = { text -> viewModel.handleUserUtterance(text) { reply -> speechOutput?.speak(reply) } },
            onError = { err -> viewModel.setError(err) },
            onListeningChange = { listening -> if (listening) viewModel.setListening() }
        )

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val state by viewModel.state.collectAsState()
                val messages by viewModel.messages.collectAsState()
                val apiKeySet by viewModel.apiKeySet.collectAsState()

                JarvisScreen(
                    state = state,
                    messages = messages,
                    apiKeySet = apiKeySet,
                    onMicClick = { onMicClick() },
                    onSendText = { text -> viewModel.handleUserUtterance(text) { reply -> speechOutput?.speak(reply) } },
                    onSaveApiKey = { key -> viewModel.saveApiKey(key) }
                )
            }
        }
    }

    private fun onMicClick() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        speechInput?.startListening()
    }

    override fun onDestroy() {
        super.onDestroy()
        speechInput?.destroy()
        speechOutput?.shutdown()
    }
}
