package com.alp.jarvis

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import com.alp.jarvis.core.JarvisState
import com.alp.jarvis.service.JarvisBackgroundService
import com.alp.jarvis.ui.JarvisScreen
import com.alp.jarvis.voice.SpeechInput

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()
    private var speechInput: SpeechInput? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* sonuclar ilgili tetikleyicilerde kontrol edilir */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val startupPerms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            startupPerms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(startupPerms.toTypedArray())

        // Sesle baslatilan bir konusma bittiginde mikrofonu otomatik tekrar ac
        // (surekli sesli sohbet modu).
        viewModel.onAutoRelisten = { onMicClick(forceListen = true) }

        speechInput = SpeechInput(
            context = this,
            onResult = { text -> viewModel.handleUserUtterance(text, fromVoice = true) },
            onError = { err -> viewModel.setError(err) },
            onListeningChange = { listening -> if (listening) viewModel.setListening() }
        )

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val state by viewModel.state.collectAsState()
                val messages by viewModel.messages.collectAsState()
                val apiKeySet by viewModel.apiKeySet.collectAsState()
                val cameraOpen by viewModel.cameraOpen.collectAsState()
                val currentVoice by viewModel.currentVoice.collectAsState()

                JarvisScreen(
                    state = state,
                    messages = messages,
                    apiKeySet = apiKeySet,
                    cameraOpen = cameraOpen,
                    currentVoice = currentVoice,
                    onMicClick = { onMicClick(forceListen = false) },
                    onSendText = { text -> viewModel.handleUserUtterance(text, fromVoice = false) },
                    onSaveApiKey = { key -> viewModel.saveApiKey(key) },
                    onSaveVoice = { voice -> viewModel.saveVoice(voice) },
                    onCameraToggle = { open -> onCameraToggle(open) },
                    onBackgroundListenToggle = { enabled -> onBackgroundListenToggle(enabled) }
                )
            }
        }
    }

    private fun onMicClick(forceListen: Boolean) {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }

        // Kullanici konusma modu aktifken mikrofona tekrar dokunursa, bunu
        // "sesli sohbeti durdur" olarak yorumla (otomatik tekrar dinlemeyi kes).
        if (!forceListen && viewModel.state.value != JarvisState.IDLE) {
            viewModel.stopVoiceMode()
            speechInput?.stopListening()
            return
        }

        speechInput?.startListening()
    }

    private fun onCameraToggle(open: Boolean) {
        if (open) {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                return
            }
        }
        viewModel.toggleCamera(open)
    }

    private fun onBackgroundListenToggle(enabled: Boolean) {
        if (enabled) {
            val micGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (!micGranted) {
                permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                return
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val notifGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
                if (!notifGranted) {
                    permissionLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
                    return
                }
            }
            JarvisBackgroundService.start(this)
        } else {
            JarvisBackgroundService.stop(this)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechInput?.destroy()
    }
}
