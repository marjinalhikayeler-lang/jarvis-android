package com.alp.jarvis

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.alp.jarvis.accessibility.AccessibilityUtils
import com.alp.jarvis.core.JarvisEngineHolder
import com.alp.jarvis.core.JarvisState
import com.alp.jarvis.service.JarvisBackgroundService
import com.alp.jarvis.ui.JarvisScreen
import com.alp.jarvis.voice.SpeechInput
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()
    private var speechInput: SpeechInput? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* sonuclar ilgili tetikleyicilerde kontrol edilir */ }

    private val roleRequestLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { /* sonuc onemli degil, kullanici secimini kendi yapar */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val startupPerms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            startupPerms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(startupPerms.toTypedArray())

        // Kullanici daha once "arka planda dinle"yi actiysa (ve uygulama sureci
        // yeniden baslatildiysa) servisi otomatik tekrar ayaga kaldir.
        lifecycleScope.launch {
            val wasEnabled = JarvisEngineHolder.get(this@MainActivity).getBackgroundListeningPref()
            if (wasEnabled) {
                JarvisBackgroundService.start(this@MainActivity)
            }
        }

        // Sesle baslatilan bir konusma bittiginde mikrofonu otomatik tekrar ac
        // (surekli sesli sohbet modu).
        viewModel.onAutoRelisten = { onMicClick(forceListen = true) }

        speechInput = SpeechInput(
            context = this,
            onResult = { text -> viewModel.handleUserUtterance(text, fromVoice = true) },
            onError = { err -> viewModel.setError(err) },
            onListeningChange = { listening -> if (listening) viewModel.setListening() }
        )

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val state by viewModel.state.collectAsState()
                val messages by viewModel.messages.collectAsState()
                val apiKeySet by viewModel.apiKeySet.collectAsState()
                val cameraOpen by viewModel.cameraOpen.collectAsState()
                val currentVoice by viewModel.currentVoice.collectAsState()
                val backgroundListening by viewModel.backgroundListening.collectAsState()

                JarvisScreen(
                    state = state,
                    messages = messages,
                    apiKeySet = apiKeySet,
                    cameraOpen = cameraOpen,
                    currentVoice = currentVoice,
                    backgroundListening = backgroundListening,
                    accessibilityEnabled = AccessibilityUtils.isServiceEnabled(this@MainActivity),
                    onMicClick = { onMicClick(forceListen = false) },
                    onSendText = { text -> viewModel.handleUserUtterance(text, fromVoice = false) },
                    onSaveApiKey = { key -> viewModel.saveApiKey(key) },
                    onSaveVoice = { voice -> viewModel.saveVoice(voice) },
                    onCameraToggle = { open -> onCameraToggle(open) },
                    onBackgroundListenToggle = { enabled -> onBackgroundListenToggle(enabled) },
                    onOpenAccessibilitySettings = { AccessibilityUtils.openAccessibilitySettings(this@MainActivity) },
                    onOpenCallScreeningSettings = { requestCallScreeningRole() }
                )
            }
        }
    }

    private fun onMicClick(forceListen: Boolean) {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }

        // Kullanici konusma modu aktifken mikrofona tekrar dokunursa, bunu
        // "sesli sohbeti durdur" olarak yorumla (otomatik tekrar dinlemeyi kes).
        if (!forceListen && viewModel.state.value != JarvisState.IDLE) {
            viewModel.stopVoiceMode()
            speechInput?.stopListening()
            return
        }

        speechInput?.startListening()
    }

    private fun onCameraToggle(open: Boolean) {
        if (open) {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                return
            }
        }
        viewModel.toggleCamera(open)
    }

    private fun onBackgroundListenToggle(enabled: Boolean) {
        if (enabled) {
            val micGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (!micGranted) {
                permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                return // izin yoksa anahtar kaydedilmez, Switch kapali kalir
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val notifGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
                if (!notifGranted) {
                    permissionLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
                    return
                }
            }
            JarvisBackgroundService.start(this)
            viewModel.setBackgroundListeningState(true)
        } else {
            JarvisBackgroundService.stop(this)
            viewModel.setBackgroundListeningState(false)
        }
    }

    /** JARVIS'i telefonun "Arama Filtreleme" uygulamasi olarak secme ekranini acar. */
    private fun requestCallScreeningRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
                !roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
            ) {
                roleRequestLauncher.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
                return
            }
        }
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
        } catch (e: Exception) {
            // Bu ekran cihazda yoksa sessizce gec
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechInput?.destroy()
    }
}
