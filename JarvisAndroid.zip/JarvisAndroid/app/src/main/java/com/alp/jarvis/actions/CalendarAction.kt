package com.alp.jarvis.actions

import android.content.ContentValues
import android.content.Context
import android.provider.CalendarContract
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/**
 * Windows suerumundeki actions/calendar.py (Apple Calendar) karsiligi.
 * Android'de CalendarContract ile cihazin senkronize takvimine
 * (genelde Google Takvim) dogrudan okuma/yazma yapilir.
 */
object CalendarAction {

    private fun firstWritableCalendarId(context: Context): Long? {
        val projection = arrayOf(CalendarContract.Calendars._ID)
        context.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI, projection,
            "${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL} >= ?",
            arrayOf(CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR.toString()),
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                return cursor.getLong(0)
            }
        }
        return null
    }

    fun getEvents(context: Context, query: String): String {
        val now = Calendar.getInstance()
        val start: Long
        val end: Long

        when {
            query.contains("yarın", true) || query.contains("tomorrow", true) -> {
                now.add(Calendar.DAY_OF_YEAR, 1)
                now.set(Calendar.HOUR_OF_DAY, 0); now.set(Calendar.MINUTE, 0)
                start = now.timeInMillis
                now.add(Calendar.DAY_OF_YEAR, 1)
                end = now.timeInMillis
            }
            query.contains("hafta", true) || query.contains("week", true) -> {
                start = now.timeInMillis
                now.add(Calendar.DAY_OF_YEAR, 7)
                end = now.timeInMillis
            }
            query.contains("ay", true) || query.contains("month", true) -> {
                start = now.timeInMillis
                now.add(Calendar.MONTH, 1)
                end = now.timeInMillis
            }
            else -> { // today / default
                now.set(Calendar.HOUR_OF_DAY, 0); now.set(Calendar.MINUTE, 0)
                start = now.timeInMillis
                now.add(Calendar.DAY_OF_YEAR, 1)
                end = now.timeInMillis
            }
        }

        val uriBuilder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        android.content.ContentUris.appendId(uriBuilder, start)
        android.content.ContentUris.appendId(uriBuilder, end)

        val projection = arrayOf(
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END
        )

        val results = mutableListOf<String>()
        val fmt = SimpleDateFormat("d MMM HH:mm", Locale("tr"))

        context.contentResolver.query(uriBuilder.build(), projection, null, null, "${CalendarContract.Instances.BEGIN} ASC")
            ?.use { cursor ->
                while (cursor.moveToNext()) {
                    val title = cursor.getString(0) ?: "(Başlıksız)"
                    val begin = cursor.getLong(1)
                    results.add("$title — ${fmt.format(Date(begin))}")
                }
            }

        return if (results.isEmpty()) "Bu aralıkta takvimde etkinlik yok."
        else "Takvimdeki etkinlikler:\n" + results.joinToString("\n")
    }

    fun addEvent(context: Context, title: String, startIso: String, endIso: String?): String {
        val calId = firstWritableCalendarId(context) ?: return "Yazılabilir bir takvim bulunamadı. Google hesabı bağlı mı?"

        val startMillis = try {
            parseIso(startIso)
        } catch (e: Exception) {
            return "Tarih anlaşılamadı: $startIso"
        }
        val endMillis = if (!endIso.isNullOrBlank()) {
            try { parseIso(endIso) } catch (e: Exception) { startMillis + 60 * 60 * 1000 }
        } else {
            startMillis + 60 * 60 * 1000 // varsayılan 1 saat
        }

        val values = ContentValues().apply {
            put(CalendarContract.Events.DTSTART, startMillis)
            put(CalendarContract.Events.DTEND, endMillis)
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.CALENDAR_ID, calId)
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
        }

        val uri = context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
        return if (uri != null) "\"$title\" takvime eklendi." else "Etkinlik eklenirken bir sorun oluştu."
    }

    private fun parseIso(iso: String): Long {
        val formats = listOf(
            "yyyy-MM-dd'T'HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm",
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd HH:mm",
            "yyyy-MM-dd"
        )
        for (f in formats) {
            try {
                val sdf = SimpleDateFormat(f, Locale.getDefault())
                return sdf.parse(iso)!!.time
            } catch (_: Exception) {}
        }
        throw IllegalArgumentException("Geçersiz tarih formatı")
    }
}

private fun Date(millis: Long) = java.util.Date(millis)
