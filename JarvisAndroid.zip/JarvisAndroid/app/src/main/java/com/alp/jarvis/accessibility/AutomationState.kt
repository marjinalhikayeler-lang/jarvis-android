package com.alp.jarvis.accessibility

enum class PendingAction { NONE, WHATSAPP_SEND, WHATSAPP_CALL, SPOTIFY_PLAY_FIRST }

/**
 * WhatsAppAction/SpotifyAction bir uygulamayi actiginda burada "bekleyen
 * bir aksiyon var" diye isaretler; JarvisAccessibilityService ekran
 * degistiginde bunu görüp ilgili dugmeye kendisi dokunur.
 */
object AutomationState {
    @Volatile
    var pending: PendingAction = PendingAction.NONE
        private set

    @Volatile
    private var expiresAt: Long = 0L

    fun request(action: PendingAction, windowMs: Long = 20000) {
        pending = action
        expiresAt = System.currentTimeMillis() + windowMs
    }

    fun isActive(): Boolean {
        if (pending == PendingAction.NONE) return false
        if (System.currentTimeMillis() > expiresAt) {
            pending = PendingAction.NONE
            return false
        }
        return true
    }

    fun clear() {
        pending = PendingAction.NONE
    }
}
