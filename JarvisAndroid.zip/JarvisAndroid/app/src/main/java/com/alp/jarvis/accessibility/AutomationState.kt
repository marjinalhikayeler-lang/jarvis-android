package com.alp.jarvis.accessibility

enum class PendingAction { NONE, WHATSAPP_SEND, WHATSAPP_CALL, SPOTIFY_PLAY_FIRST }

/**
 * WhatsAppAction/SpotifyAction bir uygulamayi actiginda burada "bekleyen
 * bir aksiyon var" diye isaretler; JarvisAccessibilityService ekran
 * degistiginde bunu görüp ilgili dugmeye kendisi dokunur.
 */
object AutomationState {
    @Volatile
    var pending: PendingAction = PendingAction.NONE
        private set

    /** send_whatsapp_message icin gonderilen mesaj metni — sabit buton ID'si
     *  bulunamazsa, bu metnin yazildigi kutunun yanindaki simgeyi arayarak
     *  ID degisikliklerine karsi daha dayanikli olmayi saglar. */
    @Volatile
    var messageHint: String? = null
        private set

    @Volatile
    private var expiresAt: Long = 0L

    fun request(action: PendingAction, hint: String? = null, windowMs: Long = 20000) {
        pending = action
        messageHint = hint
        expiresAt = System.currentTimeMillis() + windowMs
    }

    fun isActive(): Boolean {
        if (pending == PendingAction.NONE) return false
        if (System.currentTimeMillis() > expiresAt) {
            pending = PendingAction.NONE
            messageHint = null
            return false
        }
        return true
    }

    fun clear() {
        pending = PendingAction.NONE
        messageHint = null
    }
}
