package com.alp.jarvis.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.alp.jarvis.accessibility.AccessibilityUtils
import com.alp.jarvis.accessibility.AutomationState
import com.alp.jarvis.accessibility.PendingAction

/**
 * Spotify'in resmi bir "ilk sonucu cal" baglantisi yok. Erisilebilirlik
 * izni aciksa JarvisAccessibilityService arama sonuclarindaki ilk
 * sarkiya kendisi dokunur (en iyi caba — Spotify arayuzu guncellenirse
 * bozulabilir). Kapaliysa sadece arama ekranini acar.
 */
object SpotifyAction {

    fun playSearch(context: Context, query: String): String {
        val automationOn = AccessibilityUtils.isServiceEnabled(context)
        if (automationOn) AutomationState.request(PendingAction.SPOTIFY_PLAY_FIRST)

        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(query)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                setPackage("com.spotify.music")
            }
            context.startActivity(intent)
            if (automationOn) "Spotify'da \"$query\" çalınıyor."
            else "Spotify'da \"$query\" arandı, ilk sonuca dokunup çalabilirsin. " +
                "Otomatik çalması için Ayarlar'dan Erişilebilirlik iznini bir kez açman gerekiyor."
        } catch (e: Exception) {
            AutomationState.clear()
            val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/search/${Uri.encode(query)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(web)
            "Spotify yüklü değil gibi görünüyor, tarayıcıda \"$query\" aramasını açtım."
        }
    }
}
