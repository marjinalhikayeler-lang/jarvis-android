package com.alp.jarvis.core

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

val Context.dataStore by preferencesDataStore(name = "jarvis_memory")

/**
 * Windows suerumundeki memory/memory_manager.py karsiligi.
 * Kayitlari JSON dizisi olarak DataStore'da saklar:
 * [{ "category": ..., "key": ..., "value": ... }, ...]
 */
class MemoryManager(private val context: Context) {

    private val MEMORY_KEY = stringPreferencesKey("memory_json")

    suspend fun load(): JSONArray {
        val prefs = context.dataStore.data.first()
        val raw = prefs[MEMORY_KEY] ?: "[]"
        return try { JSONArray(raw) } catch (e: Exception) { JSONArray() }
    }

    suspend fun save(category: String, key: String, value: String): String {
        val arr = load()
        // ayni key varsa guncelle
        var updated = false
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            if (item.optString("key") == key) {
                item.put("value", value)
                item.put("category", category)
                updated = true
                break
            }
        }
        if (!updated) {
            val item = JSONObject()
            item.put("category", category)
            item.put("key", key)
            item.put("value", value)
            arr.put(item)
        }
        persist(arr)
        return "Not edildi: $key = $value"
    }

    suspend fun delete(matchText: String): String {
        val arr = load()
        val newArr = JSONArray()
        var removed = false
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            val hay = "${item.optString("key")} ${item.optString("value")} ${item.optString("category")}".lowercase()
            if (hay.contains(matchText.lowercase())) {
                removed = true
                continue
            }
            newArr.put(item)
        }
        persist(newArr)
        return if (removed) "Hafızadan silindi." else "Eşleşen bir kayıt bulamadım."
    }

    private suspend fun persist(arr: JSONArray) {
        context.dataStore.edit { prefs ->
            prefs[MEMORY_KEY] = arr.toString()
        }
    }

    suspend fun formatForPrompt(): String {
        val arr = load()
        if (arr.length() == 0) return "(Henüz kayıtlı bir bilgi yok)"
        val lines = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            lines.add("- [${item.optString("category")}] ${item.optString("key")}: ${item.optString("value")}")
        }
        return lines.joinToString("\n")
    }
}
