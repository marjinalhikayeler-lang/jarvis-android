package com.alp.jarvis.actions

import android.content.Context
import android.media.AudioManager

/**
 * Yeni ozellik: sesi yuzde bazinda ayarlama/kisma-artirma. Arka planda
 * baska bir uygulamadayken "Jarvis sesi %10 kis" gibi komutlar icin.
 */
object VolumeAction {

    /** percent: 0-100 arasi hedef medya ses seviyesi */
    fun setVolumePercent(context: Context, percent: Int): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = ((percent.coerceIn(0, 100)) / 100f * max).toInt().coerceIn(0, max)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
        return "Ses seviyesi %${percent.coerceIn(0, 100)} olarak ayarlandı."
    }

    /** deltaPercent: -100..100 arasi, mevcut sesin uzerine eklenir/cikarilir */
    fun adjustVolumePercent(context: Context, deltaPercent: Int): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val current = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val currentPercent = current * 100f / max
        val newPercent = (currentPercent + deltaPercent).coerceIn(0f, 100f)
        val target = (newPercent / 100f * max).toInt().coerceIn(0, max)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
        val verb = if (deltaPercent < 0) "kısıldı" else "artırıldı"
        return "Ses $verb, şimdi %${newPercent.toInt()}."
    }
}
