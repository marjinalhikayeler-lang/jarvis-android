package com.alp.jarvis.camera

/**
 * Kamera acikken en son cekilen kareyi (JPEG) tutar. CameraPreviewView
 * icindeki ImageAnalysis analyzer'i bunu duzenli olarak gunceller;
 * MainViewModel bir mesaj gonderilirken buradan son kareyi okuyup
 * Gemini'ye gorsel olarak ekler ("JARVIS gorsun" ozelligi).
 */
object CameraFrameHolder {
    @Volatile
    var latestJpeg: ByteArray? = null
        private set

    fun update(jpeg: ByteArray) {
        latestJpeg = jpeg
    }

    fun clear() {
        latestJpeg = null
    }
}
