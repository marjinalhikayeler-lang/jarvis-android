package com.alp.jarvis.telecom

import android.telecom.Call
import android.telecom.CallScreeningService
import com.alp.jarvis.core.CallPolicy

/**
 * Kullanici "gelen aramaları reddet" dediginde CallPolicy.autoReject
 * true olur; bu servis sistem tarafindan HER gelen arama icin cagrilir
 * (JARVIS'in "Arama Filtreleme" uygulamasi olarak secilmis olmasi
 * gerekir — Ayarlar'daki ilgili buton bu ekrani acar).
 */
class JarvisCallScreeningService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        val response = if (CallPolicy.autoReject) {
            CallResponse.Builder()
                .setDisallowCall(true)
                .setRejectCall(true)
                .setSkipNotification(false)
                .build()
        } else {
            CallResponse.Builder().build()
        }
        respondToCall(callDetails, response)
    }
}
