package com.alp.jarvis.telecom

import android.telecom.Call
import android.telecom.CallScreeningService
import com.alp.jarvis.core.CallPolicy
import com.alp.jarvis.core.SettingsStore
import kotlinx.coroutines.runBlocking

/**
 * Kullanici "gelen aramaları reddet" dediginde tercih diske kaydedilir
 * (SettingsStore). Android, bu servisi bazen uygulamanin geri kalani hic
 * calismadan, SADECE bu servisi baslatmak icin cagirabiliyor — o zaman
 * CallPolicy.autoReject gibi bellekteki bir degisken hala varsayilan
 * (false) degerinde olur. Bu yuzden burada HER seferinde dogrudan
 * diskten okuyoruz, bellege guvenmiyoruz.
 */
class JarvisCallScreeningService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        val autoReject = try {
            runBlocking { SettingsStore(applicationContext).getCallAutoReject() }
        } catch (e: Exception) {
            CallPolicy.autoReject // diskten okunamazsa bellekteki son bilinen degere dus
        }
        CallPolicy.autoReject = autoReject // bellegi de guncel tut

        val response = if (autoReject) {
            CallResponse.Builder()
                .setDisallowCall(true)
                .setRejectCall(true)
                .setSkipNotification(false)
                .build()
        } else {
            CallResponse.Builder().build()
        }
        respondToCall(callDetails, response)
    }
}
