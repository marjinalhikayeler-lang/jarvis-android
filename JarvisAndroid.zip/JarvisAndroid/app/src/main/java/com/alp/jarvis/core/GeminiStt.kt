package com.alp.jarvis.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Android'in yerlesik ses tanimasi bazi cihazlarda (Google uygulamasi
 * kapali/kisitli) hic calismiyor. Bunun yerine ham ses kaydini Gemini'ye
 * gonderip yaziya cevirtiyoruz — cihaz kisitlamasindan bagimsiz, sadece
 * mikrofon + internet yeterli.
 */
object GeminiStt {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private const val MODEL = "gemini-3.6-flash"
    private val URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    suspend fun transcribe(apiKey: String, wavBytes: ByteArray): String? = withContext(Dispatchers.IO) {
        try {
            val b64 = android.util.Base64.encodeToString(wavBytes, android.util.Base64.NO_WRAP)
            val parts = JSONArray()
                .put(
                    JSONObject().put(
                        "text",
                        "Bu ses kaydını sadece olduğu gibi yazıya dök. Açıklama, yorum veya ek bir şey ekleme; sadece söylenen kelimeleri yaz."
                    )
                )
                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/wav").put("data", b64)))

            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))

            val request = Request.Builder()
                .url("$URL?key=$apiKey")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                val bodyStr = resp.body?.string() ?: return@withContext null
                val json = JSONObject(bodyStr)
                val candidates = json.optJSONArray("candidates") ?: return@withContext null
                if (candidates.length() == 0) return@withContext null
                val respParts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                    ?: return@withContext null

                val sb = StringBuilder()
                for (i in 0 until respParts.length()) {
                    val p = respParts.getJSONObject(i)
                    if (p.has("text")) sb.append(p.getString("text"))
                }
                val text = sb.toString().trim()
                if (text.isBlank()) null else text
            }
        } catch (e: Exception) {
            null
        }
    }
}
